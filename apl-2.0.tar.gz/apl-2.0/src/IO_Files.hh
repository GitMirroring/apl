/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#ifndef __IO_FILES_HH_DEFINED__
#define __IO_FILES_HH_DEFINED__

#include <stdio.h>
#include <iostream>
#include <fstream>

#include "Assert.hh"
#include "UTF8_string.hh"

using namespace std;

/*
 The classes below are used to combine normal user I/O and automatic
 testcase execution. It works like this:

       (cin)
         │
         │
         V
     ╔═══════╗             ╔═══════════════════╗
     ║ Input ║ <────────── ║ testcase files(s) ║
     ╚═══════╝             ╚═══════════════════╝
         │                           │
         │                           │
         V                           │
      ╔═════╗                        │
      ║ APL ║                        │
      ╚═════╝                        │
         │                           │
         │                           │
         ├───────────────────────┐   │
         │                       │   │
         │                       V   V
         │                    ╔═════════╗
         │                    ║ compare ║
         │                    ╚═════════╝
         │                         │
         │                         │
         V                         V
       (cout)                (test results)
 
 */

//════════════════════════════════════════════════════════════════════════════
/** handling of Input files. IO_Files reads lines from files until they
    are all executed. The output of the APL interpreter is compared against
    the testcase files and mismatches are recorded.
 */
/// a sequence of files that are still to be executed
class IO_Files
{
   friend int main(int argc, const char *argv[]);
   friend class UserPreferences;

public:
   /// true if the line requested from get_file_line() is for the ∇-editor
   static bool nabla_reading;

   /// the APL input (⍞, ⎕, or ⎕INP) that requested the line from
   /// get_file_line(), or 0 if the line is not for such an input
   static const char * apl_reading;

   /// set by get_file_line() when a testcase file ended while an APL input
   /// (⍞, ⎕, or ⎕INP) was pending. That input shall then be abandoned
   /// (with an INTERRUPT) before the testcase is ended (Bugs40 #2)
   static bool abandon_apl_read;

   /// end the current testcase after a line error (--TM 5 or 6)
   static void line_error_done();

   /// finish a test run that is ended by )OFF or --OFF and return the
   /// exit status (Bugs40 #78)
   static int finish_tests(int exit_val);

   /// stop (and maybe exit) after a testcase file with \b errors errors,
   /// depending on --TM. Return true if stopped.
   static bool stop_after_failed_file(int errors);

   /// true if diff_error() has found a line error with --TM 5 or 6
   static bool line_error_pending;

   /// set by get_file_line() when a testcase file ended inside a ∇-editor
   /// session or a multi-line string, which shall then be abandoned
   /// (Bugs39 #52)
   static bool abandon_input;

   /// count an error
   static void reset_errors()
      {
        apl_errors = 0;
        assert_errors = 0;
        diff_errors = 0;
        parse_errors = 0;
      }

   /// return the total number of errors
   static int error_count()
      { return apl_errors + assert_errors + diff_errors + parse_errors; }

   /// return \b true iff the interpreter shall exit after a file I/O error
   static bool exit_on_error()
      { return test_mode == TM_EXIT_AFTER_FILE_ERROR; }

   /// return \b true iff --TM 3 (stop testing after the first file error,
   /// but stay in the interpreter rather than exit()ing) is active.
   static bool is_stop_after_file_error()
      { return test_mode == TM_STOP_AFTER_FILE_ERROR; }

   /// count and report a parse error
   static void syntax_error();

   /// reset APL errors, expecting at most max_cnt errors
   /// @param max_cnt the expected error count
   static void expect_apl_errors(int max_cnt);

   /// count an APL error
   /// @param loc caller location for diagnostics
   static void apl_error(const char * loc);

   /// count a failed assertion
   static void assert_error();

   /// write a summary.log entry (and print "Failed testcase is ...") for
   /// the testcase file that is executing right now, if any -- for a
   /// crash (CrashDump::crash_handler()) or an internal-consistency
   /// failure (the FIXME macro, via fixme_exit_code()), both of which
   /// exit() directly without ever reaching end_of_current_file(). Without
   /// this, such a file is silently missing from summary.log entirely
   /// (not even a "0 errors" line), making it invisible to tooling that
   /// parses summary.log for the first failure (src/Automated_Test_Report.sh).
   /// Also persists a raw backtrace to disk under get_crash_backtrace_path()
   /// (see there) so it survives independent of whatever, if anything,
   /// later captures CERR. No-op if no testcase file is currently being
   /// read.
   static void report_abnormal_exit();

   /// set summary_path to summary.log in the directory of the first
   /// testcase file, and truncate it
   /// unless \b append (--TS). Called once, after all -T and --TL options
   /// were parsed, so that all testcases of a run share one summary.log.
   static void init_summary(bool append);

   /// the file path used by report_abnormal_exit() to persist a raw
   /// backtrace for the testcase file that is executing right now (the
   /// same testcase named in its summary.log entry), so that a crash's
   /// or FIXME's backtrace is available on disk even though CERR itself
   /// is not normally captured anywhere durable. Returns an empty string
   /// if no testcase file is currently being read (mirrors
   /// report_abnormal_exit()'s own no-op condition).
   static UTF8_string get_crash_backtrace_path();

   /// count a output diff error
   static void diff_error();

   /// get one line from the current file, open the next file if necceessary
   /// @param line output buffer for the line read
   /// @param eof set to true when no more input is available
   static void get_file_line(UTF8_string & line, bool & eof);

   /// open the next test file 
   static void open_next_file();

   /// close current testcase file (prematurely) and opem mext one
   static void next_file();

   /// return the current test report
   static ofstream & get_current_testreport()
      { return current_testreport; }

   /// read one line from the current input file with CR and LF removed
   /// @param file_line output buffer for the line read
   /// @param eof set to true when end of file is reached
   static void read_file_line(UTF8_string & file_line, bool & eof);

   /// modes for ]FILE_CTL (see Cmd_HOST::cmd_FILE_CTL()): lines between
   /// a ]FILE_CTL command and the next one (or end of file, or )CLEAR)
   /// are discarded by read_file_line() -- without ever reaching the
   /// tokenizer/executor -- when SKIP_mode says so for the interpreter
   /// currently reading them. Real APL2 has no such command; the
   /// MEGA-workspace-based cross-check harness emulates the SKIP_APL2
   /// effect itself (this enum/flag has no meaning there).
   static enum Skip_mode
      {
        /// don't skip anything (default; also the state after )CLEAR)
        SKIP_NONE  = 0,

        /// skip while GNU APL is the interpreter reading this file
        SKIP_GNU   = 1,

        /// skip while (emulated) real APL2 is reading this file --
        /// meaningless to GNU APL's own read_file_line(), which never
        /// skips for this value; only the APL2-side MEGA-workspace
        /// emulation acts on it
        SKIP_APL2  = 2,

        /// skip unconditionally (start of what amounts to a multi-line
        /// comment, regardless of which interpreter is reading it)
        SKIP_ALL   = 3,
      } skip_mode;

protected:
   /// how to handle test results
   static enum TestMode
      {
        /// exit() after the last testcase file was processed.
        TM_EXIT_AFTER_LAST_FILE       = 1 << 0,

        /// exit() after the last testcase file was processed and no error
        /// was detected.
        TM_EXIT_AFTER_LAST_FILE_IF_OK = 1 << 1,

        /// remain in APL interpreter after the last testcase
        /// file was processed.
        TM_STAY_AFTER_LAST_FILE       = 1 << 2,

        /// stop test execution after the first testcase file failed (but
        /// remain in the APL interpreter)
        TM_STOP_AFTER_FILE_ERROR      = 1 << 3,

        /// exit() after the first testcase file failed
        TM_EXIT_AFTER_FILE_ERROR      = 1 << 4,

        /// exit() after the first comparison (= testcase file line) failed
        TM_EXIT_AFTER_LINE_ERROR      = 1 << 5,

        /// stop test execution after the first testcase line failed (but
        TM_STOP_AFTER_LINE_ERROR      = 1 << 6,

        /// done if the first testcase line has failed
        TM_DONE_AFTER_LINE_ERROR = TM_STOP_AFTER_LINE_ERROR
                                 | TM_EXIT_AFTER_LINE_ERROR,
      } test_mode;   ///< the desired test mode as per --TM n

   /// dito (close files, print errors, summary etc).
   static bool end_of_current_file();

   /// write testcases summary file
   static void print_summary();

   /// true until total error count is printed.
   static bool need_total;


   /// the number of testcases provided
   static int testcase_count;

   /// the number of testcases executed
   static int testcases_done;

   /// the number of parse errors when executing test file
   static int parse_errors;

   /// the tital number of errors in all test files
   static int total_errors;

   /// the number of APL errors when executing in current file
   static int apl_errors;

   /// the source location where the last APL error was thrown
   static const char * last_apl_error_loc;

   /// the testcase file line that has triggered the last APL error
   static int last_apl_error_line;

   /// the number of output differences when executing test file
   static int diff_errors;

   /// the number of failed assertions when executing test file
   static int assert_errors;

   /// the current test report
   static ofstream current_testreport;

   /// name of the summary file (same directory as first testcase, see
   /// init_summary()).
   static UTF8_string summary_path;

   /// when a .tc file was started
   static APL_time_us start_usecs;
};
//════════════════════════════════════════════════════════════════════════════

#endif // __IO_FILES_HH_DEFINED__
