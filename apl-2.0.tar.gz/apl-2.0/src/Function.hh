/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#ifndef __FUNCTION_HH_DEFINED__
#define __FUNCTION_HH_DEFINED__

#include <sys/types.h>

#include "Error.hh"
#include "NamedObject.hh"
#include "Parser.hh"
#include "PrintBuffer.hh"
#include "Value.hh"

class Workspace;
class UserFunction;
class RavelIterator;

/* Naming conventions for the virtual eval_XXX() functions (in the order of
   appearance in suffix XXX (from left to right).

   A: left value argument (functions and operators)
   L: left function argument (monadic and dyadic operators)
   R: right function argument  (dyadic operators)
   X: axis argument (functions and operators)
   B: right value argument (functions and operators)

   default implementation functions with axis: ignore axis
*/
//════════════════════════════════════════════════════════════════════════════
/** additional functionality for functions with named sub-functions.
    I.e one of ⌹, ⎕CR, ⎕FFT, FIO, ⎕MX, ⎕RVAL, or ⎕SQL.
  */
class FunctionGroup
{
protected:
   /// information pertaining to one subfunction
   struct function_info
      {
        /// the function axis (= function number)
        sAxis axis;

        /// the function name (for e.g. ⎕XXX.function_name) in Prefix.cc
        const char * function_name;

        /// the comment in ⎕XXX '' (mapping == true; currently only used
        /// by  ⎕SQL only).
        /// the syntax table is sorted by function names
        const char * comment_map;

        /// the comment in ⎕XXX ⍬ (mapping = false).
        /// the syntax table is sorted by function number
        const char * comment_fun;

        /// ther function valence, -1 if not specified
        int valence;
      };

public:
   /// default constructor (for functions that are NOT function groups)
   FunctionGroup()
   : group_name(0),
     subfun_count(0),
     max_function_name_length(0)
   {}

   /// initialize \b sorted_by_name and \b sorted_by_axis.
   /// @param infos array of function_info entries describing each subfunction
   /// @param count number of entries in \b infos
   /// @param group_name the name of this function group (e.g. "⎕SQL")
   void init_function_group(const function_info * infos, size_t count,
                            const char * group_name);

   /// return \b true if \b this function has (named) sub-functions.
   /// Most do not.
   bool has_subfuns() const
      { return subfun_count != 0; }

   /// return a function number (pseudo-axis) for subfunction \b name,
   /// or -1 if \b name is not a valid subfunction name
   /// @param subfun_name the subfunction name to look up
   sAxis subfun_to_axis(const UCS_string & subfun_name) const;

   /// return a function number (pseudo-axis) for \b value. \b value shall
   /// be an integer scalar, or else a valid subfunction name (APL string).
   /// @param A_or_X APL value that is either an integer axis or a name string
   sAxis value_to_subfun(const cValue & A_or_X) const;
   //
   /// print some help (not for )HELP, but for ⎕XXX ⍬).
   /// The help for )HELP is defined in \b Help.def
   /// @param out output stream to print to
   Token list_functions(ostream & out) const;

   /// print the syntax variants for all subfunctions.
   /// @param out output stream to print to
   Token list_mappings(ostream & out) const;

   /// complain about an invalid subfunctioon name
   /// @param sub_name the invalid subfunction name that was requested
   void bad_subfun_name_ERROR(const UCS_string sub_name) const GNUC__noreturn;

   /// complain about an invalid subfunctioon name
   /// @param number the invalid subfunction number that was requested
   void bad_subfun_number_ERROR(int number) const GNUC__noreturn;

   /// static texts before and after syntax tables
   enum Legend_type
      {
        LET_FUN_PREFIX,   ///< ⎕XXX '' starr
        LET_FUN_SUFFIX,   ///< ⎕XXX '' end
        LET_MAP_PREFIX,   ///< ⎕XXX ⍬ starr
        LET_MAP_SUFFIX,   ///< ⎕XXX ⍬ end
      };

protected:
   /// helper function to print a 1-line function help.
   /// @param lt which legend text (prefix/suffix for function or mapping table)
   virtual const char * get_legend(Legend_type lt) const
      { return ""; }   // for non-FunctionGroups

   /// helper function to print the subfunction function syntax
   /// @param out output stream to print to
   virtual void print_fun_syntax(ostream & out, const function_info &) const
      { out << "*** missing FunctionGroup::print_fun_syntax()" << endl; }

   /// helper function to print the subfunction syntax mapping
   /// @param out output stream to print to
   virtual void print_map_syntax(ostream & out, const function_info &) const
      { out << "*** missing FunctionGroup::print_map_syntax()" << endl; }

   /// compare names. Return \b > 0 if info1 > info2
   /// @param name the function name key to compare against
   /// @param info pointer to the function_info entry to compare with
   static int compare_function_name(const char * const & name,
                                     const function_info * const & info,
                                     const void *);

   /// compare axes. Return \b > 0 if info1 > info2
   /// @param key the axis number key to compare against
   /// @param info pointer to the function_info entry to compare with
   static int compare_function_axis(const uAxis & key,
                                    const function_info * const & info,
                                    const void *);

   /// compare names. Return \b true if info1 > info2
   static bool greater_function_name(const function_info * const & info1,
                                     const function_info * const & info2,
                                     const void *)
      { return compare_function_name(info1->function_name, info2, 0) > 0; }

   /// compare axes. Return \b true if info1 > info2
   static bool greater_function_axis(const function_info * const & info1,
                                     const function_info * const & info2,
                                     const void *)
      { return compare_function_axis(info1->axis, info2, 0) > 0; }
 
   /// return the function_info for function name \b name
   /// @param name the subfunction name to look up
   const function_info * get_info_by_name(const char * name) const;

   /// return the function_info for function axis \b axis
   /// @param axis the function axis number to look up
   const function_info * get_info_by_axis(uAxis axis) const;

   /// return the signature \b sig as string
   /// @param sig the function signature bitmask to stringify
   UCS_string get_signature_string(Fun_signature sig) const;

   /// the group name (⎕CR, ⎕FFT, ... Only non-zero if this functiuon is a group
   /// (ass opposed to being a function without subfunctions).
   const char * group_name;

   /// the table, sorted by function name
   vector<const function_info *> sorted_by_name;

   /// the table, sorted by function number (= axis)
   vector<const function_info *> sorted_by_axis;

   /// the number of subfunctions
   int subfun_count;

   /// the longest subfunction name (for tabular output)
   size_t max_function_name_length;
};
//────────────────────────────────────────────────────────────────────────────
/** The base class for all functions (user defined or system functions).  */
/// Base class for all APL functions and operators (system or defined)
class Function : public NamedObject, public FunctionGroup
{
public:
   /// constructor for most functions
   Function(TokenTag _tag)
   : NamedObject(Id(_tag >> 16)),
     creation_time(0),
     tag(_tag)
   { parallel_thresholds[0] = parallel_thresholds[1] = -1; }

   /// constructor for functions whose Id does not match their tag
   Function(Id id, TokenTag _tag)
   : NamedObject(id),
     creation_time(0),
     tag(_tag)
   { parallel_thresholds[0] = parallel_thresholds[1] = -1; }

   /// destructor
   virtual ~Function()
   {}

   /// a monadic Cell function that returns bool
   typedef bool (*bool_f1)(const Cell & B);

   /// a dyadic Cell function that returns bool
   typedef bool (*bool_f2)(const Cell & A, const Cell & B);

   /// a monadic function that returns packed bool for packed A
   typedef uint64_t (*bool_f1_bool)(uint64_t A);

   /// a dyadic function that returns packed bool for packed A and packed B
   typedef uint64_t (*bool_f2_bool)(uint64_t A, uint64_t B);

   /// an associative cell function
   typedef ErrorCode (Cell::*assoc_f2)(Cell *, const Cell *) const;

   /// Quad_CR of this function.
   virtual UCS_string canonical(bool with_lines) const
      { NeverReach("Function::canonical() called"); return UCS_string(); }

   /// if this function is an associative scalar function then return
   /// its associative cell function, otherwise 0.
   virtual assoc_f2 get_assoc() const
      { return 0; }

   /// return \b a bool_f1() (if any), otherwise 0.
   virtual bool_f1 get_bool_f1() const
      { return 0; }

   /// return \b a bool_f1() (if any), otherwise 0.
   virtual bool_f1_bool get_bool_f1_bool() const
      { return 0; }

   /// return \b a bool_f2() (if any), otherwise 0.
   virtual bool_f2 get_bool_f2() const
      { return 0; }

   /// return \b a bool_f2() (if any), otherwise 0.
   virtual bool_f2_bool get_bool_f2_bool() const
      { return 0; }

   /// GMT when this function was created; 0 for system functions
   APL_time_us get_creation_time() const
      {  return creation_time; }

   /// the dyadic inverse function of \b this function (if any)
   virtual cFunction_P get_dyadic_inverse() const   { return 0; }

   /// return break-even point for dyadic parallel execution
   ShapeItem get_dyadic_threshold() const
      { return parallel_thresholds[1]; }

   /// return the execution properties (3 ⎕AT) for this function
   virtual const int * get_exec_properties() const
      { static int ep[] = { 1, 1, 1, 0 };   return ep; }

   /// return the number of value arguments (0, 1, or 2) of a user defined
   /// function, For non-user defined functions, throw DOMAIN_ERROR.
   virtual int get_fun_valence() const
      {
        const TokenClass tc = TokenClass(int(tag) & int(TC_MASK));
        if (tc == TC_FUN2)   return 2;
        if (tc == TC_FUN1)   return 1;
        return 0;
      }

   /// return a pointer to \b this UserFunction (if it is one)
   virtual const UserFunction * get_func_ufun() const   { return 0; }

   /// overloaded NamedObject::get_function()
   virtual const Function * get_function() const   { return this; }

   /// the monadic inverse function of \b this function (if any)
   virtual cFunction_P get_monadic_inverse() const   { return 0; }

   /// return break-even point for monadic parallel execution
   ShapeItem get_monadic_threshold() const
      { return parallel_thresholds[0]; }

   /// return the number of function arguments (1 or 2) of an operator,
   /// or 0 for a "normal" function that isn't an operator.
   virtual int get_oper_valence() const   { return 0; }

   /// return the dyadic scalar primitive if \b this function
   virtual prim_f2 get_scalar_f2() const
      { return 0; }

   /// return the \b Token Tag for \b this function.
   TokenTag get_tag() const { return tag; }

   /// return a \b Token for \b this function.
   Token get_token() const { return Token(tag, this); }

   /// return true if this function has a name with alphabetic chars,
   /// i.e. the function is either a defined function or a ⎕-function
   virtual bool has_alpha() const   { return false; }

   /// return true iff the function has and axis (system functions
   /// always have an axis even though most of them ignore it).
   virtual bool has_axis() const    { return true; }

   /// return \b true iff \b this function returns a (possibly nested)
   /// boolean result and takes (only) boolean arguments.
   /// For example: ∧, ∨, ∼, ...
   virtual bool is_bool_bool() const
      { return 0; }

   /// return \b true iff \b this function is defined (= has an APL body)
   virtual bool is_defined() const   { return false; }

   /// return \b true iff \b this function is a derived function
   virtual bool is_derived() const
      { return false; }

   /// return \b true iff \b this function is a lambda
   virtual bool is_lambda() const   { return false; }

   /// return \b true iff \b this function is a macro
   virtual bool is_macro() const   { return false; }

   /// return \b true iff \b this is a native function
   virtual bool is_native() const   { return false; }

   /// return \b true iff \b this is an operator.
   virtual bool is_operator() const   { return false; }

   virtual bool is_scalar_function() const   { return false; }

   /// return axis (non-0 only for derived functions)
   virtual Value_P * locate_X() const
      { return 0; }

   /// return \b true if \b eval_XXX may push the SI. True for ⍎, user defined
   /// functions, and operators derived from user defined functions
   virtual bool may_push_SI() const   { return false; }

   /// return the valence(s) (see Fun_selectivity) for which \b this
   /// function genuinely selects/overtakes its right argument, i.e. may
   /// legitimately appear on the left of ← in a selective specification.
   /// An operator whose operand can appear there (e.g. ¨) must check
   /// this -- and has_result() -- before handing the operand a live
   /// LvalCell; never rely on is_defined()/may_push_SI() for that (a
   /// primitive can be just as non-selecting as a defined function, e.g.
   /// scalar +, and a defined function is never selecting at all since
   /// this is never overridden for one).
   virtual Fun_selectivity get_selectivity() const   { return SEL_NONE; }

   /// return \b true iff \b this function can genuinely be called
   /// monadically at all (i.e. has a real eval_B()/eval_XB(), not just
   /// the Function:: default that phrase_error()s unconditionally).
   /// Needed because get_signature()/get_fun_valence() cannot answer
   /// this for primitives: TC_FUN1, TC_FUN2 and TC_FUN12 all collapse to
   /// the same TokenClass value (TokenEnums.hh), so the base
   /// get_fun_valence() always reports 2 for any primitive regardless of
   /// which eval_XXX it actually overrides -- it is only meaningful for
   /// UserFunction, which overrides it from the declared header. A
   /// selective-specification guard checking is_left_value() must know
   /// this BEFORE calling eval_B(): calling a monadic-incapable
   /// primitive is always safe on its own (phrase_error() never touches
   /// B), so such a call must be let through to its natural VALENCE
   /// ERROR rather than intercepted and misreported as SYNTAX ERROR.
   /// Default true (most primitives and all monadic-capable functions);
   /// override to false only for a primitive with no monadic form at
   /// all (e.g. Bif_F12_DROP, Bif_F2_INDEX).
   virtual bool has_monadic_form() const   { return true; }

   /// return \b true iff \b this function can genuinely be called
   /// dyadically at all. See has_monadic_form() for the full rationale;
   /// this is its dyadic mirror (relevant to the innermost step of a
   /// selective-spec chain, e.g. (2 H V)←9 for a monadic-only defined H).
   virtual bool has_dyadic_form() const   { return true; }

   /// plain function, 0 arguments
   virtual Token eval_() const;

   /// plain function, 2 arguments
   virtual Token eval_AB(cValue_R A, cValue_R B) const;

   /// monadic operator, 2 arguments
   virtual Token eval_ALB(cValue_R A, Token & LO, cValue_R B) const;

   /// dyadic operator, 2 arguments
   virtual Token eval_ALRB(cValue_R A, Token & LO, Token & RO, cValue_R B) const;

   /// dyadic operator, 2 arguments, plus axis
   virtual Token eval_ALRXB(cValue_R A, Token & LO, Token & RO,
                            cValue_R X, cValue_R B) const;

   /// monadic operator, 2 arguments, plus axis
   virtual Token eval_ALXB(cValue_R A, Token & LO, cValue_R X, cValue_R B) const;

   /// plain function, 2 arguments, plus axis
   virtual Token eval_AXB(cValue_R A, cValue_R X, cValue_R B) const;

   /// plain function, 1 argument
   virtual Token eval_B(cValue_R B) const;

   /// monadic operator, 1 argument
   virtual Token eval_LB(Token & LO, cValue_R B) const;

   /// dyadic operator, 1 arguments
   virtual Token eval_LRB(Token & LO, Token & RO, cValue_R B) const;

   /// dyadic operator, 1 arguments, plus axis
   virtual Token eval_LRXB(Token & LO, Token & RO, cValue_R X, cValue_R B) const;

   /// monadic operator, 1 arguments, plus axis
   virtual Token eval_LXB(Token & LO, cValue_R X, cValue_R B) const;

   /// plain function, 1 argument, plus axis
   virtual Token eval_XB(cValue_R X, cValue_R B) const;

   /// Evaluate \b the fill function.
   virtual Token eval_fill_AB(cValue_R A, cValue_R B) const;

   /// Evaluate \b the fill function.
   virtual Token eval_fill_B(cValue_R B) const;

   /** Evaluate \b the identity function. B is empty and the result is a
   /// value f/B0 with (B0 f ↑B) ≡ B for all B (and f is \b this function).
   /// If such a B0 does not exist then raise a DOMAIN ERROR.

       NOTE that eval_identity_fun() returns f/B0 and not B0 !!!
    **/
   virtual Token eval_identity_fun(cValue_R B, sAxis axis) const;

   /// store the attributes (as per ⎕AT) of symbol in Z, ...
   virtual void get_attributes(int mode, Value & Z) const;

   /// return the signature of this function (currently only valid
   /// for user-defined functions)
   Fun_signature get_signature() const;

   /// return 1 if the function returns a result, otherwise 0.
   /// For non-user defined functions, throw DOMAIN_ERROR.
   virtual bool has_result() const = 0;

   /// raise an invalid phrase error
   Token phrase_error(const char * pattern) const;

   /// Print \b this function.
   virtual ostream & print(ostream & out) const = 0;

   /// print the properties of this function
   virtual void print_properties(ostream & out, int indent) const = 0;

   /// Delete this function (do nothing, overloaded by UserFunction).
   virtual void destroy() {}

   /// set the time when the function was created (0 for built-in functions)
   void set_creation_time(APL_time_us t)
      { creation_time = t; }

   /// set the break-even point for dyadic parallel execution
   void set_dyadic_threshold(ShapeItem new_threshold)
      { parallel_thresholds[1] = new_threshold; }

   /// set the break-even point for monadic parallel execution
   void set_monadic_threshold(ShapeItem new_threshold)
      { parallel_thresholds[0] = new_threshold; }

   /// when this function was created (0.0 for system functions)
   APL_time_us creation_time;

protected:
   /// the thresholds for parallel execution
   ShapeItem parallel_thresholds[2];

   /// the tag for token pointing to \b this function
   TokenTag tag;
};
//════════════════════════════════════════════════════════════════════════════

#endif // __FUNCTION_HH_DEFINED__
