/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#include "Sys.hh"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>

#if HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif // HAVE_NETINET_IN_H

#if HAVE_SYS_IOCTL_H
# include <sys/ioctl.h>
#endif // HAVE_SYS_IOCTL_H

#if HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif // HAVE_SYS_SOCKET_H

#if HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif // HAVE_SYS_SELECT_H

#include <sys/stat.h>

#if HAVE_SYS_UN_H
#include <sys/un.h>   // for sockaddr_un
#endif // HAVE_SYS_UN_H

#if HAVE_WINSOCK2_H
# include <winsock2.h>
#endif // HAVE_WINSOCK2_H

#include "Bif_OPER2_INNER.hh"
#include "Bif_OPER2_OUTER.hh"
#include "Bif_OPER1_EACH.hh"
#include "Common.hh"
#include "FloatCell.hh"
#include "IntCell.hh"
#include "PointerCell.hh"
#include "Quad_FIO.hh"
#include "Performance.hh"
#include "Security.hh"
#include "StateIndicator.hh"
#include "Tokenizer.hh"
#include "Workspace.hh"

#if MINGW_SRC
#define NOT_MINGW(x) { MINGW_more(__FUNCTION__, __LINE__); }
#else
#define NOT_MINGW(x) x
#define SOCKET(x) x
#endif // MINGW_SRC

GNUC__noreturn void
MINGW_more(const char * fun, int line)
{
   MORE_ERROR() <<
   "Function is not available when GNU is cross-compiled (!) to\n"
   "Windows. On Windows: consider compiling GNU APL under CYGWIN or WSL.";
   DOMAIN_ERROR;
}
extern uint64_t top_of_memory();
uint64_t Quad_FIO::benchmark_cycles_from = 0;

std::vector<Quad_FIO::file_entry> Quad_FIO::open_files;

Quad_FIO  Quad_FIO::fun;

// A union holding a sockaddr and a sockaddr_in as to avoid casting
/// between sockaddr and a sockaddr_in
union SockAddr
{
  /// an arbitrary socket address
  sockaddr    addr;

  /// an AF_INET socket address
  sockaddr_in inet;

#if HAVE_SYS_UN_H
  ///  an AF_UNIX socket address
  sockaddr_un uNix;
#endif // HAVE_SYS_UN_H
};

   // CONVENTION: all functions must have an axis argument (like X
   // in A fun[X] B); the axis argument is a function number that selects
   // one of several functions provided by ⎕FIO...
   //
   // If the axis is missing, then a list of functions implemented by
   // ⎕FIO is displayed

//════════════════════════════════════════════════════════════════════════════
const FunctionGroup::function_info Quad_FIO::subfunction_infos[] =
{
#define fio_def(N, name)   { N, #name, "", "", -1 },
#include "Quad_FIO.def"
};
//════════════════════════════════════════════════════════════════════════════
Quad_FIO::Quad_FIO()
   : QuadFunction(TOK_Quad_FIO)
{
enum { count = sizeof(subfunction_infos) / sizeof(*subfunction_infos) };
   init_function_group(subfunction_infos, count, "⎕FIO");

   // init stdin, stdout, stderr, and maybe fd 3 
   //
file_entry f0(stdin,  STDIN_FILENO);    f0.path << "stdin";
file_entry f1(stdout, STDOUT_FILENO);   f1.path << "stdout";
file_entry f2(stderr, STDERR_FILENO);   f2.path << "stderr";
   open_files.push_back(f0);
   open_files.push_back(f1);
   open_files.push_back(f2);

#if ! MINGW_SRC
   if (-1 != fcntl(3, F_GETFD))   // this process was forked from another APL
      {
        file_entry f3(0, 3);
        f3.path << "pipe-to_client";
        open_files.push_back(f3);
      }
#endif // ! MINGW_SRC
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AB(cValue_R A, cValue_R B) const
{
   CHECK_SECURITY(disable_Quad_FIO);

   if (A.get_rank() > 1)   RANK_ERROR;
   if (B.get_rank() > 1)   RANK_ERROR;

   if (B.is_str0())    return list_functions(CERR);
   if (B.is_zilde())   return list_mappings(CERR);

const APL_Integer function_number = B.get_int_value(0);
Value_P B_vp = CLONE(&B, LOC);
   switch(function_number)
      {
        case -3: // read probe A and clear it
             return eval_AB___3(CLONE(&A, LOC));

        default: break;
      }

   return list_functions(COUT);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB(cValue_R A, cValue_R X, cValue_R B) const
{
   CHECK_SECURITY(disable_Quad_FIO);

   if (A.get_rank() > 1)   RANK_ERROR;
   if (B.get_rank() > 1)   RANK_ERROR;

Value_P A_vp = CLONE(&A, LOC);
Value_P B_vp = CLONE(&B, LOC);
const sAxis function_number = value_to_subfun(X);
   switch(function_number)
      {
         case 0:   // list functions
              return list_functions(COUT);

         case 3:   // fopen(Bs, As) filename Bs mode As
              return eval_AXB__3(A_vp, B_vp);

         case 6:   // fread(Zi, 1, Ai, Bh) 1 byte per Zi
              return eval_AXB__6(A_vp, B_vp);

         case 7:   // fwrite(Ai, 1, ⍴Ai, Bh) 1 byte per Zi
              return eval_AXB__7(A_vp, B_vp);

         case 8:   // fgets(Zi, Ai, Bh) 1 byte per Zi
              return eval_AXB__8(A_vp, B_vp);

         case 13:   // fseek(Bh, Ai, SEEK_SET)
              return eval_AXB__13(A_vp, B_vp);

         case 14:   // fseek(Bh, Ai, SEEK_CUR)
              return eval_AXB__14(A_vp, B_vp);

         case 15:   // fseek(Bh, Ai, SEEK_END)
              return eval_AXB__15(A_vp, B_vp);

         case 20:   // mkdir(Bc, Ai)
              return eval_AXB__20(A_vp, B_vp);

         case 22:   // fprintf(Bh, A) ←→
                    // fprintf(FILE *stream, const char *format, ...)
              return eval_AXB__22(A_vp, B_vp);

         case 23:   // fwrite(Ac, 1, ⍴Ac, Bh) Unicode Ac Output UTF-8
              return eval_AXB__23(A_vp, B_vp);

         case 24:   // popen(Bs, As) command Bs mode As
              return eval_AXB__24(A_vp, B_vp);

         case 27:   // rename(As, Bs)
              return eval_AXB__27(A_vp, B_vp);

         case 31:   // access
              return eval_AXB__31(A_vp, B_vp);

         case 33:   // bind(Bh, Aa)
              return eval_AXB__33(A_vp, B_vp);

         case 34:   // listen(Bh, Ai)
              return eval_AXB__34(A_vp, B_vp);

         case 36:   // connect(Bh, Aa)
              return eval_AXB__36(A_vp, B_vp);

         case 37:   // recv(Bh, Zi, Ai, 0) 1 byte per Zi
              return eval_AXB__37(A_vp, B_vp);

         case 38:   // send(Bh, Ai, ⍴Ai, 0) 1 byte per Zi
              return eval_AXB__38(A_vp, B_vp);

         case 39:   // send(Bh, Ac, ⍴Ac, 0) Unicode Ac Output UTF-8
              return eval_AXB__39(A_vp, B_vp);

         case 41:   // read(Bh, Zi, Ai) 1 byte per Zi
              return eval_AXB__41(A_vp, B_vp);

         case 42:   // write(Bh, Ai, ⍴Ai) 1 byte per Zi
              return eval_AXB__42(A_vp, B_vp);

         case 43:   // write(Bh, Ac, ⍴Ac) Unicode Ac Output UTF-8
              return eval_AXB__43(A_vp, B_vp);

         case 46:   // getsockopt(Bh, A_level, A_optname, Zi)
              return eval_AXB__46(A_vp, B_vp);

         case 47:   // setsockopt(Bh, A_level, A_optname, A_optval)
              return eval_AXB__47(A_vp, B_vp);

         case 48:   // fscanf(Bh, A_format)
              return eval_AXB__48(A_vp, B_vp);

         case 55:   // sscanf(Bh, A_format)
              return eval_AXB__55(A_vp, B_vp);

         case 56:   // write nested lines As to file Bs
              return eval_AXB__56(A_vp, B_vp);

         case 58:   // sprintf(Af, B...)
              return eval_AXB__58(A_vp, B_vp);

         case 59:   // fcntl(Bh, Ai...)
              return eval_AXB__59(A_vp, B_vp);

         case 60:   // random value(s)
              return eval_AXB__60(A_vp, B_vp);

         case 202:   // set monadic parallel threshold
         case 203:   // set dyadic parallel threshold
              return eval_AXB__202(A_vp, B_vp, function_number);

        default: bad_subfun_number_ERROR(function_number);
      }
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B(cValue_R B) const
{
   CHECK_SECURITY(disable_Quad_FIO);

   if (B.get_rank() > 1)   RANK_ERROR;

   if (B.element_count() == 0)   // '' or ⍬
      {
        if (B.is_str0())    return list_functions(CERR);
        if (B.is_zilde())   return list_mappings(CERR);
        DOMAIN_ERROR;
      }

const APL_Integer function_number = B.get_int_value(0);
Value_P B_vp = CLONE(&B, LOC);
   switch(function_number)
      {
        // function_numbers < 0 refer to "hacker functions" that should not be
        // used by normal mortals.
        //
        case -18: // memory test
             return eval_B___18(B_vp);

        case -17: // emulate Assert1()
             Assert1(0 && "Simulated Assert1() (aka. ⎕FIO ¯17)");
             return Token(TOK_APL_VALUE1, IntScalar(0, LOC));

        case -16: // emulate Assert()
             Assert(0 && "Simulated Assert() (aka. ⎕FIO ¯16)");
             return Token(TOK_APL_VALUE1, IntScalar(0, LOC));

        case -15: // print performance IDs and names...
             return eval_B___15();

        case -14: // print stacks. SI_top is the ⎕FIO call, so dont show it.
             return eval_B___14();

        case -13: // total number of UCS strings
             return Token(TOK_APL_VALUE1,
                          IntScalar(UCS_string::get_total_count(), LOC));

        case -12: // sbrk()
NOT_MINGW(
             return Token(TOK_APL_VALUE1, IntScalar(top_of_memory(), LOC));
         )
        case -11: // fnew
             return Token(TOK_APL_VALUE1,
                          IntScalar(Value::fast_new_count, LOC));
        case -10: // slow new
             return Token(TOK_APL_VALUE1,
                          IntScalar(Value::slow_new_count, LOC));

        case -9: // screen height
             return eval_B___9();

        case -8: // screen width
             return eval_B___8();

        case -7: // throw a segfault
             return eval_B___7();

        case -6: // throw a segfault
             return eval_B___6();

        case -5: // return ⎕AV of IBM APL2
             return eval_B___5();

        case -4: // clear all probes (ignores B, returns 0)
             Probe::init_all();
             return Token(TOK_APL_VALUE1, IntScalar(0, LOC));

        case -3: // return the type of cycle_counter
#if HAVE_RDTSC
             return Token(TOK_APL_VALUE1, IntScalar(1, LOC));
#else
             return Token(TOK_APL_VALUE1, IntScalar(2, LOC));
#endif

        case -2: // return CPU frequency
             return eval_B___2();

        case -1: // return CPU cycle counter
             return Token(TOK_APL_VALUE1, IntScalar(cycle_counter(), LOC));

        case 0:   // list of open file descriptors
             return eval_B__0();

        case 30:   // getcwd()
             return eval_B__30(B_vp);

        default: break;
      }

   return list_functions(CERR);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB(cValue_R X, cValue_R B) const
{
   CHECK_SECURITY(disable_Quad_FIO);

   if (B.get_rank() > 1)   RANK_ERROR;

Value_P B_vp = CLONE(&B, LOC);
   switch(const APL_Integer function_number = value_to_subfun(X))
      {
         case 0:   // list functions
              return list_functions(CERR);

         case 1:   // return (last) errno
              goto out_errno;

         case 2:   // return strerror(B)
              return eval_XB__2(B_vp);

         case 3:   // fopen(Bs, "r") filename Bs
              return eval_XB__3(B_vp);

         case 4:   // fclose(Bh)
              return eval_XB__4(B_vp);

         case 5:   // errno of Bh
              {
                errno = 0;
                file_entry & fe = get_file_entry(B);
                return Token(TOK_APL_VALUE1, IntScalar(fe.fe_errno, LOC));
              }

         case 6:   // fread(Zi, 1, SMALL_BUF, Bh) 1 byte per Zi
              return eval_XB__6(B_vp);

         case 8:   // fgets(Zi, SMALL_BUF, Bh) 1 byte per Zi
              return eval_XB__8(B_vp);

         case 9:   // fgetc(Bh)
              {
                FILE * file = get_FILE(B);
                return Token(TOK_APL_VALUE1, IntScalar(fgetc(file), LOC));
              }

         case 10:   // feof(Bh)
              {
                FILE * file = get_FILE(B);
                return Token(TOK_APL_VALUE1, IntScalar(feof(file), LOC));
              }

         case 11:   // ferror(Bh)
              {
                FILE * file = get_FILE(B);
                return Token(TOK_APL_VALUE1, IntScalar(ferror(file),LOC));
              }

         case 12:   // ftell(Bh)
              {
                FILE * file = get_FILE(B);
                return Token(TOK_APL_VALUE1, IntScalar(ftell(file),LOC));
              }

         case 16:   // fflush(Bh)
              return eval_XB__16(B_vp);

         case 17:   // fsync(Bh)
              return eval_XB__17(B_vp);

         case 18:   // fstat(Bh)
              return eval_XB__18(B_vp);

         case 19:   // unlink(Bc)
              return eval_XB__19(B_vp);

         case 20:   // mkdir(Bc)
              return eval_XB__20(B_vp);

         case 21:   // rmdir(Bc)
              return eval_XB__21(B_vp);

         case 24:   // popen(Bs, "r") command Bs
              return eval_XB__24(B_vp);

         case 25:   // pclose(Bh)
              return eval_XB__25(B_vp);

         case 26:   // read entire file
              return eval_XB__26(B_vp);

         case 28:   // read directory Bs
         case 29:   // read file names in directory Bs
              return eval_XB__28(B_vp, function_number);

         case 32:   // socket(Bi=AF_INET, SOCK_STREAM, 0)
              return eval_XB__32(B_vp);

         case 34:   // listen(Bh, 10)
              return eval_XB__34(B_vp);

         case 35:   // accept(Bh)
              return eval_XB__35(B_vp);

         case 37:   // recv(Bh, Zi, SMALL_BUF, 0) 1 byte per Zi
              return eval_XB__37(B_vp);

         case 40:   // select(Br, Bw, Be, Bt)
              return eval_XB__40(B_vp);

         case 41:   // read(Bh, Zi, SMALL_BUF) 1 byte per Zi
              return eval_XB__41(B_vp);

         case 44:   // getsockname(Bh, Zi)
              return eval_XB__44(B_vp);

         case 45:   // getpeername(Bh, Zi)
              return eval_XB__45(B_vp);

         case 49:   // read entire file as nested lines
              return eval_XB__49(B_vp);

         case 50:   // gettimeofday
              return eval_XB__50(B_vp);

         case 51:   // mktime
              return eval_XB__51(B_vp);

         case 52:   // localtime
         case 53:   // gmtime
              return eval_XB__52(B_vp, function_number);

         case 54:    // chdir
              return eval_XB__54(B_vp);

         case 57:   // fork() + execve() in the child
              return eval_XB__57(B_vp);

         case 60:   // random value
              return eval_XB__60(B_vp);

         case 200:   // clear statistics Bi
         case 201:   // get statistics Bi
              return eval_XB__200(B_vp, function_number);

         case 202:   // get monadic parallel threshold
         case 203:   // get dyadic  parallel threshold
              return eval_XB__202(B_vp, function_number);

         case 61:   // secs_epoch(Bh)
              return Token(TOK_APL_VALUE1, IntScalar(secs_epoch(B), LOC));

        default: bad_subfun_number_ERROR(function_number);
      }

out_errno:
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
void
Quad_FIO::clear()
{
   // close open files, but leave stdin, stdout, and stderr open
   // we move backwards from the end until only stdin, stdout, and stderr
   // are left in open_files.
   //
   while(open_files.size() > 3)
      {
         file_entry & fe = open_files.back();
         if (fe.fe_FILE)   fclose(fe.fe_FILE);   // also closes fe.fe_fd
         else              close(fe.fe_fd);
         CERR << "WARNING: File " << fe.path << " still open - closing it"
              << endl;
        ::close(open_files.back().fe_fd);
        open_files.pop_back();
      }
}
//────────────────────────────────────────────────────────────────────────────
int
Quad_FIO::close_handle(int fd)
{
   loop(h, open_files.size())
      {
        file_entry & fe = open_files[h];
        if (fe.fe_fd != fd)   continue;

        // never close stdin, stdout, or stderr
        if (fe.fe_fd <= STDERR_FILENO)
           {
             MORE_ERROR() << "Attempt to close fd " << fe.fe_fd
                          << " (stdin, stdout, or stderr)";
             DOMAIN_ERROR;
           }

        if (fe.fe_FILE)   fclose(fe.fe_FILE);   // also closes fe.fe_fd
        else              close(fe.fe_fd);

        open_files.erase(open_files.begin() + h);
        return 0;   // OK
      }

   MORE_ERROR() << "Invalid ⎕FIO handle " << fd;
   return -EBADF;
}
//────────────────────────────────────────────────────────────────────────────
int
Quad_FIO::do_FIO_57(const UCS_string & B, char * const * envp)
{
NOT_MINGW(
int spair[2];
   if (socketpair(AF_UNIX, SOCK_STREAM, 0, spair))
      {
        MORE_ERROR() << "⎕FIO[49]: socketpair() failed: " << strerror(errno);
        DOMAIN_ERROR;
      }

const pid_t child = fork();
   if (child == -1)
      {
        MORE_ERROR() << "⎕FIO[49]: fork() failed: " << strerror(errno);
        DOMAIN_ERROR;
      }

   if (child)   // parent process: return handle
      {
        ::close(spair[1]);   // close child's end so read(spair[0]) gets EOF when child exits
        file_entry fe(0, spair[0]);
        fe.fe_may_read = true;
        fe.fe_may_write = true;
        open_files.push_back(fe);
        return fe.fe_fd;
      }

   // code executed in the forked child.,,
   // Close some fds and then execve(Bs)
   // No need to free any strings allocated here
   //
const int sock = spair[1];
   ::close(STDIN_FILENO);
   for (int j = STDERR_FILENO+2; j < 100; ++j)
       {
         if (j != sock)   ::close(j);
       }

   // make the communication socket file descriptor 3
   //  (== STDERR + 1) in the client
   //
   dup2(sock, 3);
   ::close(sock);   // close the extra reference so fd 3 is the sole owner

const UCS_string path_ucs(B);
const UTF8_string path(path_ucs);
char * filename = strdup(path.c_str());
if (!filename)   DOMAIN_ERROR;
int argc = 1;
   for (const char * f = filename; *f; ++f)
       if (f[0] == ' ' && f[1] != ' ')   ++ argc;

char ** argv = new char *[argc + 2];
int ai = 0;
char * from = filename;
   for (char * f = filename; *f; ++f)
       {
         if (*f == ' ')   // end of argument
            {
              argv[ai++] = from;
              *f = 0;
              while (f[1] == ' ')   ++f;
              from = f + 1;
            }
       }

   if (*from)  argv[ai++] = from;
   argv[ai] = 0;

   execve(filename, argv, envp);   // no return on success

   // execve() failed
   //
   free(filename);
   ::close(3);

   usleep(100000);
   CERR << "*** execve() failed in 57 ⎕CR: " << strerror(errno);
         ) // NOT_MINGW
   exit(-1);
}
//────────────────────────────────────────────────────────────────────────────
Unicode
Quad_FIO::fget_utf8(FILE * file, ShapeItem & fget_count)
{
const int b0 = fgetc(file);
   if (b0 == EOF)   return UNI_EOF;

   ++fget_count;
   if (!(b0 & 0x80))   return Unicode(b0);   // ASCII

int len,bx;
   if      ((b0 & 0xE0) == 0xC0)   { len = 2;   bx = b0 & 0x1F; }
   else if ((b0 & 0xF0) == 0xE0)   { len = 3;   bx = b0 & 0x0F; }
   else if ((b0 & 0xF8) == 0xF0)   { len = 4;   bx = b0 & 0x07; }
   else if ((b0 & 0xFC) == 0xF8)   { len = 5;   bx = b0 & 0x03; }
   else if ((b0 & 0xFE) == 0xFC)   { len = 6;   bx = b0 & 0x01; }
   else return UNI_EOF;

uint32_t uni = 0;
   loop(l, len - 1)
       {
         const int subc = fgetc(file);
         if (subc == EOF)   return UNI_EOF;
         bx  <<= 6;
         uni <<= 6;
         uni |= subc & 0x3F;
       }


   return Unicode(bx | uni);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_ALXB(cValue_R A, Token & LO, cValue_R X, cValue_R B) const
{
const APL_Integer function_number = X.get_int_value(0);
   switch(function_number)
      {
        case -1:   // benchmark monadic LO with argument B
             return eval_ALXB___1(CLONE(&A, LOC), LO, CLONE(&B, LOC));
      }

   MORE_ERROR() << "Bad function number (axis X) in operator A LO ⎕FIO[X] B";
   DOMAIN_ERROR;
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_LXB(Token & LO, cValue_R X, cValue_R B) const
{
   CHECK_SECURITY(disable_Quad_FIO);

   /* a common "mistake" is to suppress the printout of ⎕FIO by e.g.

      ⊣⎕FIO[X] B

      which lands here instead of calling eval_XB(). We "fix" that mistake...
    */
   if (LO.get_tag() == TOK_F2_LEFT)
      {
        Token result = eval_XB(X, B);
        if (result.get_tag() == TOK_APL_VALUE1)
           result.ChangeTag(TOK_APL_VALUE2);
         return result;
      }

const APL_Integer function_number = X.get_int_value(0);
   switch (function_number)
      {
        case -1:   // benchmark monadic LO with argument B
             return eval_LXB___1(LO, CLONE(&B, LOC));

        case 49:
           {
             Token lines_B = eval_XB(X, B);
             return Bif_OPER1_EACH::do_eval_LB(LO, *lines_B.get_apl_val());
           }
      }

   MORE_ERROR() <<
"Bad function number (axis X) " << function_number << " in LO ⎕FIO[X] B.\n"
"Chances are that you meant to use ⎕FIO[X] B and not LO ⎕FIO[X] B. In that\n"
"case use (⎕FIO[X]) or H←⎕FIO[X]";
   DOMAIN_ERROR;
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::list_functions(ostream & out) const
{
   out << "\n"
       << "⎕FIO is a function group. It is comprised of "
                        "the following (sub-)functions:\n"
"\n"
"   ┌─── Legend:────────────────────────────────────────────────────┐\n"
"   │    a - address family, IPv4 address, port (or errno)          │\n"
"   │    b - byte(s) (Integer(s) in the range [0-255])              │\n"
"   │    d - table of dirent structs                                │\n"
"   │    e - error code (integer as per errno.h)                    │\n"
"   │    f - format string (printf(), scanf())                      │\n"
"   │    h - file handle (small integer)                            │\n"
"   │    i - integer                                                │\n"
"   │    n - names (nested vector of strings)                       │\n"
"   │    p - path (filename string)                                 │\n"
"   │    s - string                                                 │\n"
"   │    u - time divisor: 1       - second                         │\n"
"   │                      1000    - milli second                   │\n"
"   │                      1000000 - micro second                   │\n"
"   │    y4 - seconds, wday, yday, dst (daylight saving time)       │\n"
"   │    y67- year, mon, day, hour, minute, second, [dst]           │\n"
"   │    y9 - year, mon, day, hour, minute, second, wday, yday, dst │\n"
"   │    A1, A2, ...  nested vector with elements A1, A2, ...       │\n"
"   └───────────────────────────────────────────────────────────────┘\n"
"\n"
"           ⎕FIO      ⍬   ⍝ print this text on stderr\n"
"           ⎕FIO     ''   ⍝ print function-number to -name mapping on stderr\n"
"           ⎕FIO      0   ⍝ return a list of open file descriptors\n"
"        '' ⎕FIO      ⍬   ⍝ print this text on stdout\n"
"           ⎕FIO     ''   ⍝ print function-number to -name mapping on stdout\n"
"           ⎕FIO[ 0] ''   ⍝ print this text on stderr\n"
"        '' ⎕FIO[ 0] ''   ⍝ print this text on stdout\n"
"\n"
"   Zi ←    ⎕FIO[ 1] ''   ⍝ errno (of last call)\n"
"   Zs ←    ⎕FIO[ 2] Be   ⍝ strerror(Be)\n"
"   Zh ← As ⎕FIO[ 3] Bp   ⍝ fopen(Bs, As) filename Bp mode As\n"
"   Zh ←    ⎕FIO[ 3] Bp   ⍝ fopen(Bs, \"r\") filename Bp\n"
"\n"
"File I/O functions:\n"
"\n"
"   Ze ←    ⎕FIO[ 4] Bh   ⍝ fclose(Bh)\n"
"   Ze ←    ⎕FIO[ 5] Bh   ⍝ errno (of the last call using Bh)\n"
"   Zb ←    ⎕FIO[ 6] Bh   ⍝ fread(Zi, 1, " << SMALL_BUF
                                          << ", Bh) 1 byte per Zb\n"
"   Zb ← Ai ⎕FIO[ 6] Bh   ⍝ fread(Zi, 1, Ai, Bh) 1 byte per Zb\n"
"   Zi ← Ab ⎕FIO[ 7] Bh   ⍝ fwrite(Ab, 1, ⍴Ab, Bh) 1 byte per Ab\n"
"   Zb ←    ⎕FIO[ 8] Bh   ⍝ fgets(Zb, " << SMALL_BUF << ", Bh) 1 byte per Zb\n"
"   Zb ← Ai ⎕FIO[ 8] Bh   ⍝ fgets(Zb, Ai, Bh) 1 byte per Zb\n"
"   Zb ←    ⎕FIO[ 9] Bh   ⍝ fgetc(Zb, Bh) 1 byte\n"
"   Zi ←    ⎕FIO[10] Bh   ⍝ feof(Bh)\n"
"   Ze ←    ⎕FIO[11] Bh   ⍝ ferror(Bh)\n"
"   Zi ←    ⎕FIO[12] Bh   ⍝ ftell(Bh)\n"
"   Zi ← Ai ⎕FIO[13] Bh   ⍝ fseek(Bh, Ai, SEEK_SET)\n"
"   Zi ← Ai ⎕FIO[14] Bh   ⍝ fseek(Bh, Ai, SEEK_CUR)\n"
"   Zi ← Ai ⎕FIO[15] Bh   ⍝ fseek(Bh, Ai, SEEK_END)\n"
"   Zi ←    ⎕FIO[16] Bh   ⍝ fflush(Bh)\n"
"   Zi ←    ⎕FIO[17] Bh   ⍝ fsync(Bh)\n"
"   Zi ←    ⎕FIO[18] Bh   ⍝ fstat(Bh)\n"
"   Zi ←    ⎕FIO[19] Bh   ⍝ unlink(Bc)\n"
"   Zi ←    ⎕FIO[20] Bh   ⍝ mkdir(Bc, 0777)\n"
"   Zi ← Ai ⎕FIO[20] Bh   ⍝ mkdir(Bc, AI)\n"
"   Zi ←    ⎕FIO[21] Bh   ⍝ rmdir(Bc)\n"
"   Zi ← A  ⎕FIO[22] 1    ⍝ printf(         A1, A2...) format A1\n"
"   Zi ← A  ⎕FIO[22] 2    ⍝ fprintf(stderr, A1, A2...) format A1\n"
"   Zi ← A  ⎕FIO[22] Bh   ⍝ fprintf(Bh,     A1, A2...) format A1\n"
"   Zi ← Ac ⎕FIO[23] Bh   ⍝ fwrite(Ac, 1, ⍴Ac, Bh) 1 Unicode per Ac, Output UTF8\n"
"   Zh ← As ⎕FIO[24] Bs   ⍝ popen(Bs, As) command Bs mode As\n"
"   Zh ←    ⎕FIO[24] Bs   ⍝ popen(Bs, \"r\") command Bs\n"
"   Ze ←    ⎕FIO[25] Bh   ⍝ pclose(Bh)\n"
"   Zb ←    ⎕FIO[26] Bp   ⍝ return entire file Bp as byte vector\n"
"   Zs ← Ap ⎕FIO[27] Bp   ⍝ rename file Ap to Bp\n"
"   Zd ←    ⎕FIO[28] Bp   ⍝ return content of directory Bp\n"
"   Zn ←    ⎕FIO[29] Bp   ⍝ return file names in directory Bp\n"
"   Zs ←    ⎕FIO 30       ⍝ getcwd()\n"
"   Zn ← As ⎕FIO[31] Bs   ⍝ access(As, Bp) As ϵ 'RWXF'\n"
"   Zh ←    ⎕FIO[32] Bi   ⍝ socket(Bi=AF_INET, SOCK_STREAM, 0)\n"
"   Ze ← Aa ⎕FIO[33] Bh   ⍝ bind(Bh, Aa)\n"
"   Ze ←    ⎕FIO[34] Bh   ⍝ listen(Bh, 10)\n"
"   Ze ← Ai ⎕FIO[34] Bh   ⍝ listen(Bh, Ai)\n"
"   Za ←    ⎕FIO[35] Bh   ⍝ accept(Bh)\n"
"   Ze ← Aa ⎕FIO[36] Bh   ⍝ connect(Bh, Aa)\n"
"   Zb ←    ⎕FIO[37] Bh   ⍝ recv(Bh, Zb, " << SMALL_BUF << ", 0) 1 byte per Zb\n"
"   Zb ← Ai ⎕FIO[37] Bh   ⍝ recv(Bb, Zi, Ai, 0) 1 byte per Zb\n"
"   Zi ← Ab ⎕FIO[38] Bh   ⍝ send(Bh, Ab, ⍴Ab, 0) 1 byte per Ab\n"
"   Zi ← Ac ⎕FIO[39] Bh   ⍝ send(Bh, Ac, ⍴Ac, 0) 1 Unicode per Ac, Output UTF8\n"
"   Zi ←    ⎕FIO[40] B    ⍝ select(B_read, B_write, B_exception, B_timeout)\n"
"   Zi ←    ⎕FIO[41] Bh   ⍝ read(Bh, Zi, " << SMALL_BUF << ") 1 byte per Zi\n"
"   Zb ← Ai ⎕FIO[41] Bh   ⍝ read(Bh, Zb, Ai) 1 byte per Zb\n"
"   Zi ← Ab ⎕FIO[42] Bh   ⍝ write(Bh, Ab, ⍴Ab) 1 byte per Ab\n"
"   Zi ← Ac ⎕FIO[43] Bh   ⍝ write(Bh, Ac, ⍴Ac) 1 Unicode per Ac, Output UTF8\n"
"   Za ←    ⎕FIO[44] Bh   ⍝ getsockname(Bh)\n"
"   Za ←    ⎕FIO[45] Bh   ⍝ getpeername(Bh)\n"
"   Zi ← Ai ⎕FIO[46] Bh   ⍝ getsockopt(Bh, A_level, A_optname, Zi)\n"
"   Ze ← Ai ⎕FIO[47] Bh   ⍝ setsockopt(Bh, A_level, A_optname, A_optval)\n"
"   Ze ← As ⎕FIO[48] Bh   ⍝ fscanf(Bh, As)\n"
"   Zs ←    ⎕FIO[49] Bp   ⍝ return entire file Bp as nested lines\n"
"   Zs ← LO ⎕FIO[49] Bp   ⍝ ⎕FIO[49] Bp and pipe each line through LO.\n"
"   Zi ←    ⎕FIO[50] Bu   ⍝ gettimeofday()\n"
"   Zy4←    ⎕FIO[51] By67 ⍝ mktime(By67)  Note: Jan 2, 2017 is: 2017 1 2 ...\n"
"   Zy9←    ⎕FIO[52] Bi   ⍝ localtime(Bi) Note: Jan 2, 2017 is: 2017 1 2 ...\n"
"   Zy9←    ⎕FIO[53] Bi   ⍝ gmtime(Bi)    Note: Jan 2, 2017 is: 2017 1 2 ...\n"
"   Zi ←    ⎕FIO[54] Bs   ⍝ chdir(Bs)\n"
"   Ze ← Af ⎕FIO[55] Bs   ⍝ sscanf(Bs, Af) Af is the format string\n"
"   Zs ← As ⎕FIO[56] Bp   ⍝ write nested lines As to file named Bp\n"
"   Zh ←    ⎕FIO[57] Bs   ⍝ fork() and execve(Bs, { Bs, 0}, {0})\n"
"   Zs ← Af ⎕FIO[58] B    ⍝ snprintf(Af, B...) As is the format string\n"
"   Zi ← Ai ⎕FIO[59] Bh   ⍝ fcntl(Bh, Ai...) file control\n"
"   Zi ←    ⎕FIO[60] Bi   ⍝ return a Bi-byte random integer (for setting ⎕RL)\n"
"   Zi ← 0  ⎕FIO[60] Bi   ⍝ same as monadic ⎕FIO[60] Bi (random scalar, Bi≤8)\n"
"   Zb ← 1  ⎕FIO[60] Bi   ⍝ return a vector of random bytes, (Bi ≥ ⍴Zi)\n"
"   Zi ←    ⎕FIO[61] Bv   ⍝ seconds since 1/1/1970; Bv←YYYY [MM DD [HH MM SS]]\n"
"\n"
"Benchmarking functions:\n"
"\n"
"           ⎕FIO[200] Bi   ⍝ clear statistics with ID Bi\n"
"   Zn ←    ⎕FIO[201] Bi   ⍝ get statistics with ID Bi\n"
"           ⎕FIO[202] Bs   ⍝ get monadic parallel threshold for primitive Bs\n"
"        Ai ⎕FIO[202] Bs   ⍝ set monadic parallel threshold for primitive Bs\n"
"           ⎕FIO[203] Bs   ⍝ get dyadic parallel threshold for primitive Bs\n"
"        Ai ⎕FIO[203] Bs   ⍝ set dyadic parallel threshold for primitive Bs\n"
"\n"
"The functions of ⎕FIO can be called with one of several syntax alternatives.\n"
"The syntax alternatives for ⎕FIO can be displayed with:\n\n";

   COUT <<"      " << group_name << " ⍬   ⍝ display the "
        << " syntax alternatives for " << group_name << "\n\n";

   return Token();
}
//────────────────────────────────────────────────────────────────────────────
void
Quad_FIO::print_map_syntax(ostream & out, const function_info & info) const
{
const char * name = info.function_name;
const UCS_string blanks(max_function_name_length - strlen(name), UNI_SPACE);

   out << "    ⎕FIO[" << info.axis << "]  ←→  ⎕FIO['" << name << "']"
       << blanks << "←→  ⎕FIO." << name << endl;
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::do_fprintf(FILE * outf, Value_P A)
{
   CHECK_SECURITY(disable_Quad_FIO__write);

   // A is expected to be a nested APL value. A[1] is the format string,
   // A[2...] are the values for each % field in A[1]. The result returned
   // is the number of characters (not bytes!) written to the file.
   //
UCS_string UZ;
const Value & A1 = *A->get_pointer_value(0);
UCS_string A_format(A1);
   do_snprintf(UZ, A_format, *A, 1, "⎕FIO.fprintf B");
UTF8_string utf(UZ);
   if (fwrite(utf.c_str(), 1, utf.size(), outf) != utf.size())   SYSTEM_ERROR;
   return Token(TOK_APL_VALUE1, IntScalar(UZ.size(), LOC));
}
//────────────────────────────────────────────────────────────────────────────
/// a Unicode source from either a file or a UCS_string
class File_or_String
{
public:
   /// constructor: from file
   File_or_String(FILE * f)
   : file(f),
     string(0),
     lookahead(Invalid_Unicode),
     unicodes_read(0)
   { offset = ftell(f);  }

   /// constructor: from string
   File_or_String(const UCS_string * u)
   : file(0),
     string(u),
     offset(0),
     lookahead(Invalid_Unicode),
     unicodes_read(0)
   {}

   /// return the number of characters
   ShapeItem get_count() const
      {
        if (file)    return ftell(file) - offset;
        return unicodes_read;
      }

   /// get the next character
   Unicode get_next()
      {
        if (lookahead != Invalid_Unicode)   // there is an ungotten char
           {
             const Unicode ret = lookahead;
             lookahead = Invalid_Unicode;
             // counted already, so don't count it twice
             return ret;
           }

         if (file)   // data comes from a UTF-8 encoded file
            {
              ShapeItem utf8_len = 0;
              const Unicode ret = Quad_FIO::fget_utf8(file, utf8_len);
              if (ret != UNI_EOF)   ++unicodes_read;
              return ret;
            }
         else        // data comes from a UCS_string
            {
              if (offset >= string->ssize())   return UNI_EOF;
              ++unicodes_read;
              return (*string)[offset++];
            }
      }

   /// unget uni. At most one Unicode (= lookahead char) can be ungotten.
   void unget(Unicode uni)
      {
        Assert(lookahead == Invalid_Unicode);
        lookahead = uni;
      }

   /// scan a long long in a string or in a file. Return either 0 ion error,
   /// or 1 on success (for /// the number of successful conversions).
   int scanf_long_long(const char conv, long long & value)
      {
         if (file)
            {
              // if we have read the next character from a file, then we
              // need to push it back so that fscanf() will get it.
              //
              if (lookahead != Invalid_Unicode)
                 {
                   ungetc(lookahead, file);
                   lookahead = Invalid_Unicode;
                 }
              const char fmt[] = { '%', 'l', 'l', conv, 0 };
              return fscanf(file, fmt, &value);
            }

         // string input...
         //
         char cc[40];
         unsigned int cidx = 0;
         if (lookahead == UNI_OVERBAR)
            {
              cc[cidx++] = '-';
              lookahead = Invalid_Unicode;
            }
         else if (lookahead != Invalid_Unicode)
            {
              cc[cidx++] = lookahead;
              lookahead = Invalid_Unicode;
            }

         while (cidx < (sizeof(cc) - 1) && offset < string->ssize())
            {
              const Unicode uni = get_next();
              if (Avec::is_digit(uni))       cc[cidx++] = uni;   // 0-9
              else if (uni == UNI_OVERBAR)   cc[cidx++] = '-';   // ¯
              else if (uni == UNI_MINUS)     cc[cidx++] = '-';   // -
              else { unget(uni);   break; }
            }

         cc[cidx] = 0;
         const int base =  (conv == 'X') || (conv == 'x') ? 16 : 10;
         errno = 0;
         value = strtoll(cc, 0, base);
         return errno ? 0 : 1;
      }

   /// scan a double in string or file. Return either 0 or 1 for
   /// the number of successful conversions.
   int scanf_double(const char conv, APL_Float & value)
      {
         if (file)
            {
              if (lookahead != Invalid_Unicode)
                 {
                   ungetc(lookahead, file);
                   lookahead = Invalid_Unicode;
                 }
              const char fmt[] = { '%', 'l', conv, 0 };
              return fscanf(file, fmt, &value);
            }

         // string input...
         //
         char cc[40];
         unsigned int cidx = 0;
         if (lookahead == UNI_OVERBAR)
            {
              cc[cidx++] = '-';
              lookahead = Invalid_Unicode;
            }
         else if (lookahead != Invalid_Unicode)
            {
              cc[cidx++] = lookahead;
              lookahead = Invalid_Unicode;
            }

         while (cidx < (sizeof(cc)) - 1 && offset < string->ssize())
            {
              const Unicode uni = get_next();
              if (uni == UNI_OVERBAR)                  cc[cidx++] = '-';   // ¯
              else if(strchr(".0123456789eE-", uni))   cc[cidx++] = uni;
              else { unget(uni);   break; }
            }

         cc[cidx] = 0;
         errno = 0;
         value = strtod(cc, 0);
         return errno ? 0 : 1;
      }

protected:
   /// UTF8-encoded source file (or 0 for string input)
   FILE * file;

   /// UCS_string source (or 0 for file source)
   const UCS_string * string;

   /// the next character in a string input
   ShapeItem offset;

   /// ungotten char
   Unicode lookahead;

   /// number of chars consumed thus far
   ShapeItem unicodes_read;
};
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::do_scanf(File_or_String & input, const UCS_string & format,
                   int function_number)
{
   if (format.ssize() == 0)   LENGTH_ERROR;

   // we take the total number of % as an upper bound for the number of items.
   // the real count may be lower due to %% and assugnment suppression. We fix
   // that after label out: below
   //
ShapeItem count = 0;
   loop(f, format.ssize() - 1)
      {
        if (format[f] == UNI_PERCENT)   ++count;
      }

Value_P Z(count, LOC);

Unicode lookahead = input.get_next();
   if (lookahead == UNI_EOF)   goto out;

   loop(f, format.ssize())
      {
        const Unicode fmt_ch = format[f];
        if (fmt_ch == UNI_SPACE)
           {
             // one space in the format matches 0 or more spaces in the input
             //
             while (lookahead == UNI_SPACE)
                {
                 lookahead = input.get_next();
                 if (lookahead == UNI_EOF)   goto out;
                }
             continue;
           }

        if (fmt_ch != UNI_PERCENT)
           {
             // normal character in format: match with input
             //
             match:
             if (fmt_ch != lookahead)   goto out;
             lookahead = input.get_next();
             if (lookahead == UNI_EOF)   goto out;
             continue;
           }

        ++f;   // skip (first) %
        if (f >= format.ssize())
           {
             MORE_ERROR() << "trailing '%' in scanf format string";
             DOMAIN_ERROR;
           }
        const Unicode fmt_ch1 = format[f];
        if (fmt_ch1 == UNI_PERCENT)   goto match;   // double % is %

        Unicode conv = Unicode_0;   // no conversion specifier
        int conv_len = 0;
        bool suppress = false;
        for (;f < format.ssize(); ++f)
           {
             const Unicode cc = format[f];
             if (cc == UNI_ASTERISK ||      // *: assignment character
                 cc == UNI_STAR_OPERATOR)   // ⋆: assignment character
                {
                  suppress = true;
                  continue;
                }

             if (strchr("hjlLmqtz", cc))   // type modifier
                {
                  // we provide our own conversion modifiers and ignore
                  // the conversion modifiers given by the user (that only
                  // make sense in the C/C++ context).
                  continue;
                }

             if (strchr("0123456789", cc))   // field length
                {
                  conv_len = 10*conv_len + (cc - '0');
                  continue;
                }

             if (strchr("cdDfFeginousxX[", cc))
                {
                  conv = cc;
                  break; // conversion
                }
           }

        if (conv == Unicode_0)   // no conversion specifier
           {
             MORE_ERROR() << "expecting conversion character "
                             "%, c, d, f, i, n, o, u, s, or x after %";
             DOMAIN_ERROR;
           }

        if (strchr("dDiouxX", conv))  // integer conversion
           {
             input.unget(lookahead);   // so that scanf_long_long() can read it
             long long value = 0;
             const int count = input.scanf_long_long(conv, value);
             if (count == 1 && !suppress)   Z->next_ravel_Int(value);
             else                           goto out;

             lookahead = input.get_next();
             if (lookahead == UNI_EOF)   goto out;
           }
        else if (strchr("fFeg", conv))  // float conversion
           {
             input.unget(lookahead);   // let scanf_double() read it
             APL_Float value = 0;
             const int count = input.scanf_double(conv, value);
             if (count == 1 && !suppress)   Z->next_ravel_Float(value);
             else                           goto out;

             lookahead = input.get_next();
             if (lookahead == UNI_EOF)   goto out;
           }
        else if (conv == UNI_c)  // char(s)
           {
             if (conv_len == 0)   // default: single char
                {
                  if (!suppress)   Z->next_ravel_Char(lookahead);
                  lookahead = input.get_next();
                  if (lookahead == UNI_EOF)   goto out;
                }
             else
                {
                  UCS_string ucs;
                  loop(c, conv_len)
                     {
                       ucs << lookahead;
                       lookahead = input.get_next();
                       if (lookahead == UNI_EOF)   break;
                     }

                  if (!suppress)
                     {
                       Value_P ZZ(ucs, LOC);
                       Z->next_ravel_Pointer(ZZ.get());
                     }
                }
           }
        else if (conv == UNI_s)  // string
           {
             UCS_string ucs;
             while (lookahead > UNI_SPACE)
                 {
                   ucs << lookahead;
                   if (conv_len && ucs.ssize() >= conv_len)   break;
                   lookahead = input.get_next();
                   if (lookahead == UNI_EOF)   break;
                 }

             if (!suppress)
                {
                  Value_P ZZ(ucs, LOC);
                  Z->next_ravel_Pointer(ZZ.get());
                }
           }
        else if (conv == UNI_n)  // characters consumed thus far
           {
             if (!suppress)   Z->next_ravel_Int(input.get_count());
           }
        else if (conv == UNI_L_BRACK)   // character range
           {
             ++f;   // skip [

             // 1. read the pattern range [...]
             //

             // if the first char is ^ or ∧ then the characters in the range
             // shall be excluded rather than included. The range itself is
             // not affected, though.
             //
             if (f == format.ssize())   LENGTH_ERROR;
             const bool excluding = format[f] == UNI_CIRCUMFLEX   // ^
                                 || format[f] == UNI_AND;
            if (excluding)   ++f;   // skip ^ or ∧

             UCS_string range;   // the character range to be in- or excluded
             range.reserve(format.ssize());

             // if the next char is ] then it shall belong to the range,
             // otherwise it terminates the range than ending it.
             if (f == format.ssize())   LENGTH_ERROR;
             if (format[f] == UNI_R_BRACK)   range << format[f++];

            // the characters of the range, terminated by ]
            //
            for (;;)
                {
                 if (f == format.ssize())   // end of format string
                    {
                      MORE_ERROR() << "No ] in character range A of A ⎕FIO["
                                   << function_number << "] B";
                      DOMAIN_ERROR;
                    }

                  Unicode funi = format[f];
                  if ( funi == UNI_MINUS            // maybe a character range
                    && f + 1 < format.ssize()
                    && format[f+1] != UNI_R_BRACK   // otherwise its not
                    && range.size())                // otherwise its not
                     {
                           // the minus belongs to a range A-B. With Unicode
                           // the range could become ridiculously large and
                           // we throw a length error if that happens.
                           //
                           const Unicode from = range.back();
                           const Unicode to   = format[++f];
                           if (from == to)   {}   // 1-character range
                           else if (from > to)
                              {
                                MORE_ERROR() << "Invalid character range '"
                                             << from << "'-'" << to << "'\n";
                                DOMAIN_ERROR;
                              }

                           if ((to - from) >= 96)   // more than visible ASCII
                              {
                                MORE_ERROR() << "character range '" << from
                                             << "'-'" << to << "' too large.\n";
                                LENGTH_ERROR;
                              }

                       // at this point the A-B construct is valid. Insert
                       // the characters into range...
                       //
                       for (int u = from + 1; u <= to;)
                           range << Unicode(u++);
                     }
                  if (funi == UNI_R_BRACK)   break;   // end of range
                  ++f;
                  range << funi;
                }

             // 2. create the APL result
             //
             UCS_string ucs;
             ucs.reserve(format.ssize());
             for (;;)
                 {
                   if (lookahead == UNI_EOF)                 break;
                   if (conv_len && ucs.ssize() >= conv_len)   break;

                   if (range.contains(lookahead) == excluding)
                      {
                        // lookahead is the first character after the range
                        break;
                      }
                   ucs << lookahead;

                   lookahead = input.get_next();
                 }

             // ] shall only match a nonempty sequence of characters
             //
             if (ucs.size() == 0)   goto out;   // empty sequence

             if (!suppress)
                {
                  Value_P ZZ(ucs, LOC);
                  Z->next_ravel_Pointer(ZZ.get());
                }
           }
      }

out:
   // shrink Z to the actual number of converted items
   //
const Shape sh_Z(Z->get_valid_item_count());
   while (Z->more())   Z->next_ravel_0();
   Z->check_value(LOC);
   Z->set_shape(sh_Z);

   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
void
Quad_FIO::do_snprintf(UCS_string & UZ, const UCS_string & A_format,
                    cValue_R B, int off_B, const char * funname)
{
   // A is the format string, B the nested APL values for each % field in A.
   // The result UZ is the formatted string. off_B is the starting point (1
   // for fprintf(A, ...) and 0 for snprintf(format, B ...).
   //
char numbuf[50];
const int arg_count_B = B.element_count() - off_B;
int conversion_count_A = 0;   // the number of conversions (in A_format)

#define COUNT_ARG if   (conversion_count_A++ >= arg_count_B)   goto missing_arg

   for (int fA = 0; fA < A_format.ssize(); /* no fA++ */ )
       {
         const Unicode uni = A_format[fA++];
         if (uni != UNI_PERCENT)   // not %
            {
              UZ << uni;
              continue;
            }

         // uni is % which is the start of a format field. Copy the format field
         // into to string fmt and printf() it with the next argument.
         // That is, for e.g. format = "...%42.42llf..." we want fmt to be
         // "%42.42llf"
         //
         char fmt[40];             // the naked format for one printf() item
         unsigned int fm = 0;      // an index into fmt;
         fmt[fm++] = '%';          // copy the % into fmt
         fmt[fm] = 0;              // ... and NUL-terminate: fmt is on the
                                   // stack and uninitialized, so without
                                   // this a dangling '%' at the very end
                                   // of A_format (caught below) would
                                   // print garbage left over from a
                                   // previous iteration's fmt instead of
                                   // just "%".
         bool thousands = false;   // print thousands separator (',')
         for (;;)
             {
               if (fA >= A_format.ssize())
                  {
                    // After having seen a %, the end of the format string was
                    // reached without seeing the conversion specifier.
                    // Print the string and return. This happends only if
                    // A_format is somewhat mal-formed (e.g. "ab %555"),
                    // but the C/C++ printf() functions accept it.
                    //
                    UTF8_string utf(fmt);
                    UCS_string ufmt(utf);
                    UZ << ufmt;
                    return;
                  }

               if (fm >= sizeof(fmt) - 1)
                  {
                    // After seeing a %, no conversion specifier was seen
                    // within 40 characters. Most likely the user has
                    // forgotten it. In theory the format string could be
                    // proper, but we assumt it is mal-formed.
                    // (- 1 above: every write below is fmt[fm++]=uni_1;
                    // fmt[fm]=0; i.e. 2 bytes, so fm==sizeof(fmt)-1 must
                    // also be rejected to avoid a 1-byte overflow.)
                    //
                    UTF8_string utf(fmt);
                    UCS_string ufmt(utf);
                    UZ << ufmt;
                    goto field_done;
                  }

               const Unicode uni_1 = A_format[fA++];
               switch(uni_1)
                  {
                     // flag chars and field width/precision
                     //
                     case '\'': thousands = true;
                                continue;

                     case '#':
                     case '0' ... '9':
                     case '-':
                     case ' ':
                     case '+':
                     case 'I':    // glibc
                     case '.':

                     // length modifiers
                     //
                     case 'h':
                     case 'l':
                     case 'L':
                     case 'q':
                     case 'j':
                     case 'z':
                     case 't': fmt[fm++] = uni_1;   fmt[fm] = 0;
                               continue;

                         // conversion specifiers
                         //
                     case 'd':   case 'i':   case 'o':
                     case 'u':   case 'x':   case 'X':   case 'p':
                          {
                            COUNT_ARG;
                            const Cell & cell = B.get_cravel(off_B++);
                            APL_Integer int_val;
                            if (cell.is_integer_cell())
                               {
                                 int_val = cell.get_int_value();
                               }
                            else
                               {
                                 const double fv = cell.get_real_value();
                                 if (fv < 0.0)   int_val = -int(-fv);
                                 else            int_val = int(fv);
                               }
                            fmt[fm++] = uni_1;   fmt[fm] = 0;
                            SPRINTF(numbuf, fmt, int_val);
                            if (thousands)  group_thousands(UZ, numbuf, false);
                            else            UZ << numbuf;
                          }
                          goto field_done;

                     case 'e':   case 'E':   case 'f':   case 'F':
                     case 'g':   case 'G':   case 'a':   case 'A':
                          {
                            COUNT_ARG;
                            const APL_Float float_val =
                                  B.get_real_value(off_B++);
                            fmt[fm++] = uni_1;   fmt[fm] = 0;
                            SPRINTF(numbuf, fmt, float_val);
                            if (thousands)
                               {
                                 group_thousands(UZ, numbuf, true);
                               }
                            else if (char * const dot = strchr(numbuf, '.'))
                               {
                                 *dot = 0;
                                 UZ << numbuf;
                                 UZ << Workspace::get_FC(0) << (dot + 1);
                               }
                            else
                               {
                                 UZ << numbuf;
                               }
                          }
                          goto field_done;

                     case 's':   // string or char
                          COUNT_ARG;
                          if (B.is_character_cell(off_B))
                             {
                               UZ << B.get_char_value(off_B++);
                               goto field_done;
                             }
                          {
                            Value_P str =
                                    B.get_pointer_value(off_B++);
                            UCS_string ucs(*str.get());
                            UZ << ucs;
                          }
                          goto field_done;

                     case 'c':   // single char
                          COUNT_ARG;
                          UZ << B.get_char_value(off_B++);
                          goto field_done;

                     case 'm':
                          COUNT_ARG;
                          SPRINTF(numbuf, "%s", strerror(errno));
                          UZ << numbuf;
                          goto field_done;

                     case '%':
                          if (fm == 1)   // %% is % (fm==1: only the
                                         // leading '%' copied so far)
                             {
                               UZ << UNI_PERCENT;
                               goto field_done;
                             }
                          /* no break */

                     default:
                          MORE_ERROR() << "invalid format character " << uni_1
                                       << " in " << funname;
                          DOMAIN_ERROR;   // bad format char
                  }
             }
         field_done: ;
       }

   if (B.element_count() > off_B)
      {
        const int unused = B.element_count() - off_B;
        MORE_ERROR() << unused << " unused argument(s) in argument B of: "
                     << funname << "\n" << "    " << conversion_count_A
                     << " argument(s) were used, but " << arg_count_B
                     << " were provided.\n"
                        "    The format string was: '" << A_format << "'";
        LENGTH_ERROR;
      }
      return;

missing_arg:
   MORE_ERROR() << "Too few arguments in argument B of: " << funname << "\n"
                   "    Only " << arg_count_B
                <<   " argument(s) were provided in B.\n"
                   "    The format string was: '" << A_format << "'";
    LENGTH_ERROR;
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AB___3(Value_P A)
{
APL_Integer probe = A->get_int_value(0);
   if (probe < 0)   probe = Probe::PROBE_COUNT + probe;
   if (probe >= Probe::PROBE_COUNT)
      return Token(TOK_APL_VALUE1, IntScalar(-1, LOC));

const int len = Probe::get_length(probe);
   if (len < 0)   return Token(TOK_APL_VALUE1, IntScalar(-1, LOC));

Value_P Z(len, LOC);
   loop(m, len)
       Z->next_ravel_Int(Probe::get_time(probe, m));

   Probe::init(probe);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//════════════════════════════════════════════════════════════════════════════
Token
Quad_FIO::eval_ALXB___1(Value_P A, Token & LO, Value_P B)
{
#if ! HAVE_RDTSC
   MORE_ERROR() << "Platform has no 'rtdsc' instruction.";
   DOMAIN_ERROR;
#endif

   // doit...
   //
cFunction_P fun = LO.get_function();
   Assert(fun);
   const uint64_t from = cycle_counter();
Token result = fun->eval_AB(*A, *B);
const uint64_t to = cycle_counter();
   if (result.get_tag() == TOK_SI_PUSHED)
      {
        Workspace::SI_top()->                     // pretend ⎕ES
                             set_safe_execution_depth();
        benchmark_cycles_from = from;
        return result;
      }

   // LO is a primitive
   //
   return Token(TOK_APL_VALUE1, IntScalar(to - from, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__13(Value_P A, Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
const APL_Integer pos = A->get_near_int(0);
   fseek(file, pos, SEEK_SET);
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__14(Value_P A, Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
const APL_Integer pos = A->get_near_int(0);
   fseek(file, pos, SEEK_CUR);
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__15(Value_P A, Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
const APL_Integer pos = A->get_near_int(0);
   fseek(file, pos, SEEK_END);
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__20(Value_P A, Value_P B)
{
   errno = 0;
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
#if MINGW_SRC
   mkdir(path.c_str());
#else // ! MINGW_SRC
const int mask = A->get_near_int(0);
   mkdir(path.c_str(), mask);
#endif // ! MINGW_SRC
   if (errno == EEXIST)   errno = 0;   // frequent non-error
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__202(Value_P A, Value_P B, APL_Integer function_number)
{
const APL_Integer threshold = A->get_int_value(0);
cFunction_P fun = 0;
   if (B->element_count() == 3)   // dyadic operator
      {
        const Unicode oper = B->get_char_value(1);
        if (oper != UNI_FULLSTOP)   DOMAIN_ERROR;
        fun = &Bif_OPER2_INNER::fun;
      }
   else
      {
        const Unicode prim = B->get_char_value(0);
        const Token tok = Tokenizer::tokenize_function(prim);
        if (!tok.is_function())   DOMAIN_ERROR;
        fun = tok.get_function();
      }
   if (fun == 0)   DOMAIN_ERROR;
APL_Integer old_threshold;
   if (function_number == 202)
      {
        old_threshold = fun->get_monadic_threshold();
        const_cast<Function *>(fun)->set_monadic_threshold(threshold);
      }
   else
      {
        old_threshold = fun->get_dyadic_threshold();
        const_cast<Function *>(fun)->set_dyadic_threshold(threshold);
      }
   return Token(TOK_APL_VALUE1, IntScalar(old_threshold, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__22(Value_P A, Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
   return do_fprintf(file, A);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__23(Value_P A, Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__write);
   errno = 0;
FILE * file = get_FILE(*B);
UCS_string text(*A.get());
UTF8_string utf(text);
const size_t len = fwrite(utf.c_str(), 1, utf.size(), file);
   return Token(TOK_APL_VALUE1, IntScalar(len, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__24(Value_P A, Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__exec);
NOT_MINGW(
   {
     const UCS_string mode_ucs(*A.get());
     const UCS_string path_ucs(*B.get());
     const UTF8_string mode(mode_ucs);
     const UTF8_string path(path_ucs);
     const char * m = mode.c_str();
     bool read = false;
     bool write = false;
     if      (!strncmp(m, "er", 2))     read = true;
     else if (!strncmp(m, "r" , 1))     read = true;
     else if (!strncmp(m, "ew", 2))     write = true;
     else if (!strncmp(m, "w" , 1))     write = true;
     else    DOMAIN_ERROR;
     errno = 0;
     if (FILE * f = sys_popen(path.c_str(), m))
        {
          file_entry fe(f, fileno(f));
          fe.fe_may_read = read;
          fe.fe_may_write = write;
          open_files.push_back(fe);
          return Token(TOK_APL_VALUE1, IntScalar(fe.fe_fd, LOC));
        }
     if (errno)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
     return Token(TOK_APL_VALUE1, IntScalar(-1, LOC));
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__27(Value_P A, Value_P B)
{
const UCS_string old_name_ucs(*A.get());
const UCS_string new_name_ucs(*B.get());
UTF8_string old_name(old_name_ucs);
UTF8_string new_name(new_name_ucs);
   errno = 0;
const int result = rename(old_name.c_str(), new_name.c_str());
   if (result && errno)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(result, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__3(Value_P A, Value_P B)
{
const UCS_string mode_ucs(*A.get());
const UCS_string path_ucs(*B.get());
UTF8_string mode(mode_ucs);
const UTF8_string path(path_ucs);
const char * m = mode.c_str();
bool read = false;
bool write = false;
   if      (!strncmp(m, "r+", 2))     read = write = true;
   else if (!strncmp(m, "r" , 1))     read         = true;
   else if (!strncmp(m, "w+", 2))     read = write = true;
   else if (!strncmp(m, "w" , 1))            write = true;
   else if (!strncmp(m, "a+", 2))     read = write = true;
   else if (!strncmp(m, "a" , 1))            write = true;
   else    DOMAIN_ERROR;
   errno = 0;
FILE * f = fopen(path.c_str(), m);
   if (f == 0)   return Token(TOK_APL_VALUE1, IntScalar(-1, LOC));
file_entry fe(f, fileno(f));
   fe.path = path;
   fe.fe_may_read = read;
   fe.fe_may_write = write;
   open_files.push_back(fe);
   return Token(TOK_APL_VALUE1, IntScalar(fe.fe_fd, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__31(Value_P A, Value_P B)
{
const UCS_string mode_ucs(*A.get());
const UCS_string path_ucs(*B.get());
UTF8_string permissions(mode_ucs);
const UTF8_string path(path_ucs);
int perms = 0;
   loop(a, permissions.size())
       {
         int p = permissions[a] & 0xFF;
         if      (p == 'R')   perms |= R_OK;
         else if (p == 'r')   perms |= R_OK;
         else if (p == 'W')   perms |= W_OK;
         else if (p == 'w')   perms |= W_OK;
         else if (p == 'X')   perms |= X_OK;
         else if (p == 'x')   perms |= X_OK;
         else if (p == 'F')   perms |= F_OK;
         else if (p == 'f')   perms |= F_OK;
         else DOMAIN_ERROR;
       }
   errno = 0;
const int not_ok = access(path.c_str(), perms);
   if (not_ok)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(0, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__33(Value_P A, Value_P B)
{
const int fd = get_fd(*B.get());
SockAddr addr;
   memset(&addr, 0, sizeof(addr.inet));
   addr.inet.sin_family      = A->get_int_value(0);
   addr.inet.sin_addr.s_addr = htonl(A->get_int_value(1));
   addr.inet.sin_port        = htons(A->get_int_value(2));
   errno = 0;
   bind(fd, &addr.addr, sizeof(addr.inet));
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__34(Value_P A, Value_P B)
{
const int fd = get_fd(*B.get());
APL_Integer backlog = 10;
   if (A->element_count() > 0)
      backlog = A->get_int_value(0);
   errno = 0;
   listen(fd, backlog);
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__36(Value_P A, Value_P B)
{
const int fd = get_fd(*B.get());
   errno = 0;
SockAddr addr;
   memset(&addr, 0, sizeof(addr.inet));
   addr.inet.sin_family      = A->get_int_value(0);
   addr.inet.sin_addr.s_addr = htonl(A->get_int_value(1));
   addr.inet.sin_port        = htons(A->get_int_value(2));
   errno = 0;
   connect(fd, &addr.addr, sizeof(addr));
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__37(Value_P A, Value_P B)
{
const size_t bytes = A->get_near_int(0);
const int fd = get_fd(*B.get());
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes];
   errno = 0;
const ssize_t len = recv(fd, buffer, bytes, 0);
   if (len < 0)
      {
        delete [] del;
        return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
      }
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   delete [] del;
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__38(Value_P A, Value_P B)
{
   errno = 0;
const size_t bytes = A->element_count();
const int fd = get_fd(*B.get());
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes];
   loop(z, bytes)   buffer[z] = A->get_near_int(z);
const ssize_t len = send(fd, buffer, bytes, 0);
   if (len < 0)
      {
        delete [] del;
        return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
      }
   delete [] del;
   return Token(TOK_APL_VALUE1, IntScalar(len, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__39(Value_P A, Value_P B)
{
UCS_string text(*A.get());
UTF8_string utf(text);
const int fd = get_fd(*B.get());
   errno = 0;
const ssize_t len = send(fd, utf.c_str(), utf.size(), 0);
   if (len < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(len, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__41(Value_P A, Value_P B)
{
const size_t bytes = A->get_near_int(0);
const int fd = get_fd(*B.get());
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes];
   errno = 0;
const ssize_t len = read(fd, buffer, bytes);
   if (len < 0)
      {
        delete [] del;
        return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
      }
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   delete [] del;
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__42(Value_P A, Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__write);
const size_t bytes = A->element_count();
const int fd = get_fd(*B.get());
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes];
   loop(z, bytes)   buffer[z] = A->get_byte_value(z);
   errno = 0;
const ssize_t len = write(fd, buffer, bytes);
   delete [] del;
   if (len < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(len, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__43(Value_P A, Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__write);
const int fd = get_fd(*B.get());
UCS_string text(*A.get());
UTF8_string utf(text);
   errno = 0;
const ssize_t len = write(fd, utf.c_str(), utf.size());
   if (len < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(len, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__46(Value_P A, Value_P B)
{
const APL_Integer level   = A->get_int_value(0);
const APL_Integer optname = A->get_int_value(1);
const int fd = get_fd(*B.get());
int optval = 0;
socklen_t olen = sizeof(optval);
   errno = 0;
const int ret = sys_getsockopt(fd, level, optname, &optval, &olen);
   if (ret < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(optval, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__47(Value_P A, Value_P B)
{
const APL_Integer level   = A->get_int_value(0);
const APL_Integer optname = A->get_int_value(1);
const int optval          = A->get_int_value(2);
const int fd = get_fd(*B.get());
   errno = 0;
   sys_setsockopt(fd, level, optname, &optval, sizeof(optval));
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__48(Value_P A, Value_P B)
{
FILE * file = get_FILE(*B);
const UCS_string format(*A.get());
File_or_String fos(file);
   errno = 0;
   return do_scanf(fos, format, 48);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__55(Value_P A, Value_P B)
{
const UCS_string format(*A.get());
const UCS_string data(*B.get());
File_or_String fos(&data);
   errno = 0;
   return do_scanf(fos, format, 55);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__56(Value_P A, Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__write);

   // 1. before opening the output file, check that A is valid.
   //
   errno = 0;
size_t items_written = 0;
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
   if (A->get_rank() > 1)   RANK_ERROR;
const ShapeItem line_count = A->element_count();
   loop(a, line_count)
       {
         const Cell & cA = A->get_cravel(a);
         if (!cA.is_pointer_cell())
            {
               MORE_ERROR() <<
"The left argument of A ⎕FIO[56] B is not a nested vector of strings. The\n"
"first non-nested element is A[⎕IO+" << a << "].";
               DOMAIN_ERROR;
            }

         Value_P Ai = cA.get_pointer_value();
         if (!Ai->is_char_vector())
            {
               MORE_ERROR() <<
"The left argument of A ⎕FIO[56] B is not a nested vector of strings. The\n"
"first non-string element is A[⎕IO+" << a << "].";
               DOMAIN_ERROR;
            }
       }

   // 2. at this point As is OK. Write it to file Bs.
FILE * f = fopen(path.c_str(), "w");
   if (f == 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));

   loop(a, line_count)
       {
         const Cell & cA = A->get_cravel(a);
         const Value & Ai = *cA.get_pointer_value();
         UCS_string line_ucs(Ai);
         UTF8_string line_utf(line_ucs);
         line_utf += '\n';
         const size_t len = line_utf.size();
         size_t written = fwrite(line_utf.c_str(), 1, len, f);
         if (len != written)
            {
              fclose(f);
              return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
            }
         items_written += len;
       }
   fclose(f);
   return Token(TOK_APL_VALUE1, IntScalar(items_written, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__58(Value_P A, Value_P B)
{
const UCS_string A_format(*A);
UCS_string UZ;
   do_snprintf(UZ, A_format, *B, 0, "A ⎕FIO.snprintf B");
Value_P Z(UZ, LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__59(Value_P A, Value_P B)
{
NOT_MINGW(
   {
     const int fd = get_fd(*B.get());
     errno = 0;
     int result = -1;
     switch(A->element_count())
        {
           case 1: result = fcntl(fd, A->get_int_value(0));
                   break;

           case 2: result = fcntl(fd, A->get_int_value(0),
                                      A->get_int_value(1));
                   break;

           default: LENGTH_ERROR;
        }

     if (result == -1 && errno)
        return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
     return Token(TOK_APL_VALUE1, IntScalar(result, LOC));
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__6(Value_P A, Value_P B)
{
   errno = 0;
const size_t bytes = A->get_near_int(0);
FILE * file = get_FILE(*B);
   clearerr(file);
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes];
const size_t len = fread(buffer, 1, bytes, file);
   if (len == 0)
      {
        delete [] del;
        return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
      }
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   delete [] del;
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__60(Value_P A, Value_P B)
{
   errno = 0;
   if (!A->is_scalar())   RANK_ERROR;
   if (!B->is_scalar())   RANK_ERROR;
const APL_Integer mode = A->get_int_value(0);
const APL_Integer len  = B->get_int_value(0);
   if (len < 1)    LENGTH_ERROR;
   if (len > 32)   LENGTH_ERROR;
Value_P Z = get_random(mode, len);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__7(Value_P A, Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__write);
   errno = 0;
const size_t bytes = A->element_count();
FILE * file = get_FILE(*B);
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes];
   loop(z, bytes)   buffer[z] = A->get_near_int(z);
const size_t len = fwrite(buffer, 1, bytes, file);
   delete [] del;
   return Token(TOK_APL_VALUE1, IntScalar(len, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_AXB__8(Value_P A, Value_P B)
{
   errno = 0;
   // A->get_near_int(0) is signed; copying it straight into a size_t (as
   // was done before) has no lower bound, so Ai = ¯1 wrapped to SIZE_MAX,
   // making "new char[bytes + 1]" wrap to a 0-byte allocation while
   // "bytes" (truncated to fgets's int size parameter) became ¯1 --
   // a libc that accepts a non-positive size then writes a full line into
   // that 0-byte heap buffer. Validate the signed value first.
const APL_Integer bytes_signed = A->get_near_int(0);
   if (bytes_signed < 1 || bytes_signed > 100000000)   LENGTH_ERROR;
const size_t bytes = bytes_signed;
FILE * file = get_FILE(*B);
   clearerr(file);
char small_buffer[SMALL_BUF];
char * buffer = small_buffer;
char * del = 0;
   if (bytes > sizeof(small_buffer))
      buffer = del = new char[bytes + 1];
const char * s = fgets(buffer, int(bytes), file);
const int len = s ? strlen(s) : 0;
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   delete [] del;
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B__0()
{
   errno = 0;
   Value_P Z(open_files.size(), LOC);
   loop(z, open_files.size())
       {
         Z->next_ravel_Int(open_files[z].fe_fd);
       }
   Z->set_proto_Int();
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B__30(Value_P B)
{
   errno = 0;
   char buffer[APL_PATH_MAX + 1];
   char * success = getcwd(buffer, APL_PATH_MAX);
   if (!success)
      return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));

   buffer[APL_PATH_MAX] = 0;   // just in case
   UTF8_string buffer_utf(buffer);
   UCS_string cwd(buffer_utf);

   Value_P Z(cwd, LOC);
   Z->set_proto_Spc();
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___14()
{
   // SI_top is the ⎕FIO call, so dont show it.
   for (StateIndicator * si = Workspace::SI_top()->get_parent();
        si; si = si->get_parent())
       {
         CERR << "[" << si->get_level() << "]: ";
         si->get_prefix().print_stack(CERR, ".");
       }
    return Token(TOK_APL_VALUE1, IntScalar(0, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___15()
{
const ShapeItem count = PFS_MAX3;
Shape sh(count, 2);
Value_P Z(sh, LOC);
#define perfo_4(id, b, name, thr) perfo_1(id, b, name, thr)
#define perfo_3(id, b, name, thr) perfo_1(id, b, name, thr)
#define perfo_2(id, b, name, thr) perfo_1(id, b, name, thr)
#define perfo_1(id, ab, name, _thr)         \
   { Z->next_ravel_Int(PFS_ ## id ## ab);   \
     UCS_string ucs(UTF8_string(#id #ab));  \
     Value_P uZ(ucs, LOC);                  \
     Z->next_ravel_Pointer(uZ.get());       }
#include "Performance.def"
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___18(Value_P B)
{
const int64_t blocks = B->get_int_value(1);
const int64_t verbo  = B->get_int_value(2);
   // blocks * 512 below is computed in signed 64-bit and can itself wrap
   // to a small (or negative) value for a large blocks, in which case the
   // allocation SUCCEEDS at the wrapped-small size while probe_memory()
   // still writes using the original, huge blocks -- an OOB write that
   // the try/catch(bad_alloc) below does not catch, since no exception is
   // thrown in that case. Reject blocks that would overflow first.
   if (blocks < 1 || uint64_t(blocks) > SIZE_MAX / 512)   WS_FULL;
uint64_t * p = 0;
   try { p = new uint64_t[blocks * 512]; }
   catch (std::bad_alloc &) { WS_FULL; }
   catch (...)              { FIXME; }
   if (p == 0)
      {
         const APL_Integer K_bytes = blocks * 4;
         const APL_Integer M_bytes = K_bytes / 1024;
         CERR << "NOTE: " << blocks << " blocks = " << K_bytes
              << " Kbytes = " << M_bytes << " MBytes." << endl;
        WS_FULL;
      }

const APL_Integer errors =
      Sys::probe_memory(p, blocks, verbo);
   delete[] p;
   return Token(TOK_APL_VALUE1, IntScalar(errors, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___2()
{
timeval tv = { 0, 100000 }; // 100 ms
const uint64_t from = cycle_counter();
   select(0, 0, 0, 0, &tv);
const uint64_t to = cycle_counter();

   return Token(TOK_APL_VALUE1, IntScalar(10*(to - from), LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___5()
{
Value_P Z(256, LOC);
const Unicode * ibm = Avec::IBM_quad_AV();
   loop(c, 256)   Z->next_ravel_Char(ibm[c]);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//════════════════════════════════════════════════════════════════════════════
Token
Quad_FIO::eval_B___6()
{
NOT_MINGW(
   {
     CERR << "NOTE: Resetting SIGSEGV handler and triggering "
             "a segfault..." << endl;

     // reset the SSEGV handler
     //
     struct sigaction action;
     memset(&action, 0, sizeof(struct sigaction));
     action.sa_handler = 0;
     sigaction(SIGSEGV, &action, 0);
     const APL_Integer result = *reinterpret_cast<char *>(4343);
     CERR << "NOTE: Throwing a segfault failed." << endl;
     return Token(TOK_APL_VALUE1, IntScalar(result, LOC));
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___7()
{
   CERR << "NOTE: Triggering a segfault (keeping the current "
           "SIGSEGV handler)..." << endl;

const APL_Integer result = *reinterpret_cast<char *>(4343);
   CERR << "NOTE: Throwing a segfault failed." << endl;
   return Token(TOK_APL_VALUE1, IntScalar(result, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___8()
{
NOT_MINGW(
   {
     struct winsize ws;
     ioctl(STDIN_FILENO, TIOCGWINSZ, &ws);
     if (ws.ws_col)
        return Token(TOK_APL_VALUE1, IntScalar(ws.ws_col, LOC));
   }
) // NOT_MINGW
   return Token(TOK_APL_VALUE1, IntScalar(Workspace::get_PW(), LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_B___9()
{
NOT_MINGW(
   {
     struct winsize ws;
     ioctl(STDIN_FILENO, TIOCGWINSZ, &ws);
     return Token(TOK_APL_VALUE1, IntScalar(ws.ws_row, LOC));
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_LXB___1(Token & LO, Value_P B)
{
#if ! HAVE_RDTSC
   MORE_ERROR() << "Platform has no 'rtdsc' instruction.";
   DOMAIN_ERROR;
#endif

   // doit...
   //
cFunction_P fun = LO.get_function();
   Assert(fun);
const uint64_t from = cycle_counter();
   Workspace::SI_top()->set_safe_execution_depth();   // pretend ⎕ES
Token result = fun->eval_B(*B);
   if (result.get_tag() == TOK_SI_PUSHED)
      {
        benchmark_cycles_from = from | 1;
        return result;
      }

const uint64_t to = cycle_counter();
   Workspace::SI_top()->clear_safe_execution();
   return Token(TOK_APL_VALUE1, IntScalar(to - from, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__16(Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
   fflush(file);
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__17(Value_P B)
{
NOT_MINGW(
   {
     errno = 0;
     const int fd = get_fd(*B.get());
     fsync(fd);
   }
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__18(Value_P B)
{
NOT_MINGW(
   {
     errno = 0;
     const int fd = get_fd(*B.get());
     struct stat s;
     const int result = fstat(fd, &s);
     if (result)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
     Value_P Z(Value_P(13, LOC));
     Z->next_ravel_Int(s.st_dev);
     Z->next_ravel_Int(s.st_ino);
     Z->next_ravel_Int(s.st_mode);
     Z->next_ravel_Int(s.st_nlink);
     Z->next_ravel_Int(s.st_uid);
     Z->next_ravel_Int(s.st_gid);
     Z->next_ravel_Int(s.st_rdev);
     Z->next_ravel_Int(s.st_size);
     Z->next_ravel_Int(s.st_blksize);
     Z->next_ravel_Int(s.st_blocks);
     Z->next_ravel_Int(s.st_atime);
     Z->next_ravel_Int(s.st_mtime);
     Z->next_ravel_Int(s.st_ctime);
     Z->check_value(LOC);
     return Token(TOK_APL_VALUE1, Z);
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__19(Value_P B)
{
   errno = 0;
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
   unlink(path.c_str());
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__2(Value_P B)
{
int b = B->get_near_int(0);
   if (b < 0)   b = -b;
const char * text = strerror(b);
const int len = strlen(text);
Value_P Z(len, LOC);
   loop(t, len)   Z->next_ravel_Char(Unicode(text[t]));
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__20(Value_P B)
{
   errno = 0;
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
#if MINGW_SRC
   mkdir(path.c_str());
#else // ! MINGW_SRC
   mkdir(path.c_str(), 0777);
#endif // ! MINGW_SRC
   if (errno == EEXIST)   errno = 0;   // frequent non-error
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__200(Value_P B, APL_Integer function_number)
{
const Pfstat_ID b = Pfstat_ID(B->get_int_value(0));
Statistics * stat = Performance::get_statistics(b);
   if (stat == 0)   DOMAIN_ERROR;   // bad statistics ID

   if (function_number == 200)   // reset statistics
      {
        stat->reset();
        return Token(TOK_APL_VALUE1, IntScalar(b, LOC));
      }

   // get statistics
   //
const int t = Performance::get_statistics_type(b);
UCS_string stat_name(UTF8_string(stat->get_name()));
Value_P Zsub(stat_name, LOC);
   if (t <= 2)   // cell function statistics
      {
        const Statistics_record * r1 = stat->get_first_record();
        const Statistics_record * rN = stat->get_record();
        Value_P Z(8, LOC);
        Z->next_ravel_Int(t);
        Z->next_ravel_Pointer(Zsub.get());
        Z->next_ravel_Int(r1->get_count());
        Z->next_ravel_Int(r1->get_sum());
        Z->next_ravel_Float(r1->get_sum2());
        Z->next_ravel_Int(rN->get_count());
        Z->next_ravel_Int(rN->get_sum());
        Z->next_ravel_Float(rN->get_sum2());
        Z->check_value(LOC);
        return Token(TOK_APL_VALUE1, Z);
      }
   else           // function statistics
      {
        const Statistics_record * r = stat->get_record();
        Value_P Z(5, LOC);
        Z->next_ravel_Int(t);
        Z->next_ravel_Pointer(Zsub.get());
        Z->next_ravel_Int(r->get_count());
        Z->next_ravel_Int(r->get_sum());
        Z->next_ravel_Float(r->get_sum2());
        Z->check_value(LOC);
        return Token(TOK_APL_VALUE1, Z);
      }
}
//════════════════════════════════════════════════════════════════════════════
Token
Quad_FIO::eval_XB__202(Value_P B, APL_Integer function_number)
{
const Function * fun = 0;
   if (B->element_count() == 3)   // dyadic operator
      {
        const Unicode lfun = B->get_char_value(0);
        const Unicode oper = B->get_char_value(1);
        if (oper == UNI_FULLSTOP)
           {
             if (lfun == UNI_RING_OPERATOR)   // ∘.g
                fun = &Bif_OPER2_OUTER::fun;
             else                             // f.g
                fun = &Bif_OPER2_INNER::fun;
           }
      }
   else
      {
        const Unicode prim = B->get_char_value(0);
        const Token tok = Tokenizer::tokenize_function(prim);
        if (!tok.is_function())   DOMAIN_ERROR;
        fun = tok.get_function();
      }
   if (fun == 0)   DOMAIN_ERROR;
APL_Integer old_threshold;
   if (function_number == 202)
      {
        old_threshold = fun->get_monadic_threshold();
      }
   else
      {
        old_threshold = fun->get_dyadic_threshold();
      }
   return Token(TOK_APL_VALUE1, IntScalar(old_threshold, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__21(Value_P B)
{
   errno = 0;
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
   rmdir(path.c_str());
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__24(Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__exec);
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
   errno = 0;
FILE * f = sys_popen(path.c_str(), "r");
   if (f == 0)
      {
        if (errno)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
        return Token(TOK_APL_VALUE1, IntScalar(-1, LOC));
      }
file_entry fe(f, fileno(f));
   fe.fe_may_read = true;
   open_files.push_back(fe);
   return Token(TOK_APL_VALUE1, IntScalar(fe.fe_fd, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__25(Value_P B)
{
   errno = 0;
file_entry & fe = get_file_entry(*B);

   // never pclose() stdin, stdout, or stderr (matches close_handle()'s
   // guard for fclose())
   //
   if (fe.fe_fd <= STDERR_FILENO)   DOMAIN_ERROR;

int err = EBADF;   /* Bad file number */
   if (fe.fe_FILE)
      {
        err = sys_pclose(fe.fe_FILE);

        // erase fe's own entry (not necessarily the last one)
        //
        const size_t h = &fe - &open_files[0];
        open_files.erase(open_files.begin() + h);
      }
   if (err == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(err, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__26(Value_P B)
{
NOT_MINGW(
   {
     errno = 0;
     const UCS_string path_ucs(*B.get());
     const UTF8_string path(path_ucs);
     int fd = open(path.c_str(), O_RDONLY);
     if (fd == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
     struct stat st;
     if (fstat(fd, &st))
        {
          close(fd);
          return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
        }
     if (!S_ISREG(st.st_mode))
        {
          close(fd);
          MORE_ERROR() << path << " is not a regular file";
          DOMAIN_ERROR;
        }
     const ShapeItem len = st.st_size;
     const UTF8 * data = Sys::mmap(fd, len);
     close(fd);
     if (data == 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
     Value_P Z(len, LOC);
     Z->set_proto_Spc();
     loop(z, len)   Z->next_ravel_Char(Unicode(data[z]));
     Sys::munmap(data, len);
     Z->set_proto_Spc();
     Z->check_value(LOC);
     return Token(TOK_APL_VALUE1, Z);
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__28(Value_P B, APL_Integer function_number)
{
   errno = 0;
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
DIR * dir = opendir(path.c_str());
   if (dir == 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));

vector<struct dirent> entries;
   for (;;)
       {
         dirent * entry = readdir(dir);
         if (entry == 0)   break;   // directory done

         // skip . and ..
         //
         const int entry_len = strlen(entry->d_name);
         if (entry->d_name[0] == '.')
            {
              if (entry_len == 1 ||
                  (entry_len == 2 && entry->d_name[1] == '.'))
                 continue;
            }

         entries.push_back(*entry);
       }
   closedir(dir);

Shape shape_Z(entries.size());
   if (function_number == 28)   // 5 by N matrix
      {
        shape_Z.add_shape_item(5);
      }

Value_P Z(shape_Z, LOC);

   loop(e, entries.size())
      {
        const dirent & dent = entries[e];
        if (function_number == 28)   // full dirent
           {
             // all platforms support inode number
             //
             Z->next_ravel_Int(dent.d_ino);

#ifdef _DIRENT_HAVE_D_OFF
             Z->next_ravel_Int(dent.d_off);
#else
             Z->next_ravel_1();
#endif

#ifdef _DIRENT_HAVE_D_RECLEN
             Z->next_ravel_Int(dent.d_reclen);
#else
             Z->next_ravel_1();
#endif

#ifdef _DIRENT_HAVE_D_TYPE
            Z->next_ravel_Int(dent.d_type);
#else
             Z->next_ravel_1();
#endif
           }   // function_number == 28

        UCS_string filename(UTF8_string(dent.d_name));
        Value_P Z_name(filename, LOC);
        Z->next_ravel_Pointer(Z_name.get());
      }

   Z->set_proto_Spc();
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__3(Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__open);
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
   errno = 0;
FILE * f = fopen(path.c_str(), "r");
   if (f == 0)   return Token(TOK_APL_VALUE1, IntScalar(-1, LOC));
file_entry fe(f, fileno(f));
   fe.path = path;
   fe.fe_may_read = true;
   open_files.push_back(fe);
   return Token(TOK_APL_VALUE1, IntScalar(fe.fe_fd, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__32(Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__socket);
   UNSAFE("socket", 32);
   errno = 0;
APL_Integer domain = AF_INET;
APL_Integer type = SOCK_STREAM;
APL_Integer protocol = 0;
   if (B->element_count() > 0)   domain   = B->get_int_value(0);
   if (B->element_count() > 1)   type     = B->get_int_value(1);
   if (B->element_count() > 2)   protocol = B->get_int_value(2);
const int sock = socket(domain, type, protocol);
   if (sock == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
file_entry fe(0, sock);
   fe.fe_may_read = true;
   fe.fe_may_write = true;
   open_files.push_back(fe);
   return Token(TOK_APL_VALUE1, IntScalar(fe.fe_fd, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__34(Value_P B)
{
const int fd = get_fd(*B.get());
   errno = 0;
   listen(fd, 10);
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__35(Value_P B)
{
const int fd = get_fd(*B.get());
   errno = 0;
SockAddr addr;
socklen_t alen = sizeof(addr.inet);
const int sock = accept(fd, &addr.addr, &alen);
   if (sock == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
file_entry nfe(0, sock);
   open_files.push_back(nfe);
Value_P Z(4, LOC);
   Z->next_ravel_Int(nfe.fe_fd);
   Z->next_ravel_Int(addr.inet.sin_family);
   Z->next_ravel_Int(ntohl(addr.inet.sin_addr.s_addr));
   Z->next_ravel_Int(ntohs(addr.inet.sin_port));
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__37(Value_P B)
{
   errno = 0;
const int fd = get_fd(*B.get());
char buffer[SMALL_BUF];
const ssize_t len = recv(fd, buffer, sizeof(buffer), 0);
   if (len < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__4(Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__open);
   errno = 0;
file_entry & fe = get_file_entry(*B);
   if (fe.fe_fd <= STDERR_FILENO)   DOMAIN_ERROR;
   if (fe.fe_FILE)   fclose(fe.fe_FILE);   // also closes fe.fe_fd
   else              close(fe.fe_fd);
   fe = open_files.back();       // move last file to fe
   open_files.pop_back();        // erase last file
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__40(Value_P B)
{
fd_set readfds;     FD_ZERO(&readfds);
fd_set writefds;    FD_ZERO(&writefds);
fd_set exceptfds;   FD_ZERO(&exceptfds);
timeval timeout = { 0, 0 };
fd_set * rd = 0;
fd_set * wr = 0;
fd_set * ex = 0;
timeval * to = 0;
APL_Integer max_fd = -1;

   if (B->element_count() > 4)   LENGTH_ERROR;
   if (B->element_count() < 1)   LENGTH_ERROR;

   if (B->element_count() >= 4)
      {
        const APL_Integer milli = B->get_int_value(3);
        if (milli < 0)   DOMAIN_ERROR;
        timeout.tv_sec = milli / 1000;
        timeout.tv_usec = (milli%1000) * 1000;
      }

   if (B->element_count() >= 3)
      {
        const Cell & b2 = B->get_cravel(2);
        if (!b2.is_pointer_cell())   DOMAIN_ERROR;
        Value_P vex = b2.get_pointer_value();
        loop(l, vex->element_count())
            {
              const int fd(vex->get_int_value(l));
              if (fd < 0)                       DOMAIN_ERROR;
              if (fd > 8*int(sizeof(fd_set)))   DOMAIN_ERROR;
              FD_SET(SOCKET(fd), &exceptfds);
              if (max_fd < fd)   max_fd = fd;
              ex = &exceptfds;
            }
      }

   if (B->element_count() >= 2)
      {
        const Cell & b1 = B->get_cravel(1);
        if (!b1.is_pointer_cell())   DOMAIN_ERROR;
        Value_P vwr = b1.get_pointer_value();
        loop(l, vwr->element_count())
            {
              const APL_Integer fd = vwr->get_int_value(l);
              if (fd < 0)                       DOMAIN_ERROR;
              if (fd > 8*int(sizeof(fd_set)))   DOMAIN_ERROR;
              FD_SET(SOCKET(fd), &writefds);
              if (max_fd < fd)   max_fd = fd;
              wr = &writefds;
            }
      }

   if (B->element_count() >= 1)
      {
        const Cell & b0 = B->get_cfirst();
        if (!b0.is_pointer_cell())   DOMAIN_ERROR;
        Value_P vrd = b0.get_pointer_value();
        loop(l, vrd->element_count())
            {
              const APL_Integer fd = vrd->get_int_value(l);
              if (fd < 0)                         DOMAIN_ERROR;
              if (fd > (8*int(sizeof(fd_set))))   DOMAIN_ERROR;
              FD_SET(SOCKET(fd), &readfds);
              if (max_fd < fd)   max_fd = fd;
              rd = &readfds;
            }
      }

const int count = select(max_fd + 1, rd, wr, ex, to);
   if (count < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));

Value_P Z(5, LOC);
const APL_Integer milli_seconds = timeout.tv_sec*1000 + timeout.tv_usec/1000;
   Z->next_ravel_Int(count);
   Z->next_ravel_Pointer(fds_to_val(rd, max_fd).get());
   Z->next_ravel_Pointer(fds_to_val(wr, max_fd).get());
   Z->next_ravel_Pointer(fds_to_val(ex, max_fd).get());
   Z->next_ravel_Int(milli_seconds);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__41(Value_P B)
{
   errno = 0;
const int fd = get_fd(*B.get());
char buffer[SMALL_BUF];
const ssize_t len = read(fd, buffer, sizeof(buffer));
   if (len < 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   Z->set_proto_Int();
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__44(Value_P B)
{
const int fd = get_fd(*B.get());
   errno = 0;
SockAddr addr;
socklen_t alen = sizeof(addr.inet);
const int ret = getsockname(fd, &addr.addr, &alen);
   if (ret == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
Value_P Z(3, LOC);
   Z->next_ravel_Int(addr.inet.sin_family);
   Z->next_ravel_Int(ntohl(addr.inet.sin_addr.s_addr));
   Z->next_ravel_Int(ntohs(addr.inet.sin_port));
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__45(Value_P B)
{
const int fd = get_fd(*B.get());
   errno = 0;
SockAddr addr;
socklen_t alen = sizeof(addr.inet);
const int ret = getpeername(fd, &addr.addr, &alen);
   if (ret == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
Value_P Z(3, LOC);
   Z->next_ravel_Int(addr.inet.sin_family);
   Z->next_ravel_Int(ntohl(addr.inet.sin_addr.s_addr));
   Z->next_ravel_Int(ntohs(addr.inet.sin_port));
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__49(Value_P B)
{
NOT_MINGW(
   {
     errno = 0;
     const UCS_string path_ucs(*B.get());
     const UTF8_string path(path_ucs);
     const int fd = open(path.c_str(), O_RDONLY);
     if (fd == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
     struct stat st;
     if (fstat(fd, &st))
        {
          close(fd);
          return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
        }
     if (!S_ISREG(st.st_mode))
        {
          close(fd);
          MORE_ERROR() << path << " is not a regular file";
          DOMAIN_ERROR;
        }
     const ShapeItem len = st.st_size;
     const UTF8 * data = Sys::mmap(fd, len);
     close(fd);
     if (data == 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));

     // count number of LFs in the file
     //
     ShapeItem line_count = 0;
     loop(l, len)
         {
           if (data[l] == '\n')   ++line_count;
         }

     // if the last line does not end with \n then count it as well
     if (len && data[len - 1] != '\n')   ++line_count;

     Value_P Z(line_count, LOC);
     Z->set_proto_Spc();

     const UTF8 * from = data;
     loop(l, len)
         {
           if (data[l] != '\n')   continue;
           const uint8_t * end = data + l;
          // discard CR before LF
           if (end > data && end[-1] == '\r')   --end;
           UTF8_string utf(from, end - from);
           UCS_string ucs(utf);
           Value_P ZZ(ucs, LOC);
           Z->next_ravel_Pointer(ZZ.get());
           from = data + l + 1;
         }

     if (len && data[len - 1] != '\n')   // incomplete final line
        {
           const uint8_t * end = data + len;
           if (end[-1] == '\r')   --end;   // discard trailing CR
           UTF8_string utf(from, end - from);
           UCS_string ucs(utf);
           Value_P ZZ(ucs, LOC);
           Z->next_ravel_Pointer(ZZ.get());
        }

     Sys::munmap(data, len);
     Z->set_proto_Spc();
     Z->check_value(LOC);
     return Token(TOK_APL_VALUE1, Z);
   }
) // NOT_MINGW
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__50(Value_P B)
{
const APL_Integer unit = B->get_near_int(0);
timeval tv;
   gettimeofday(&tv, 0);
int64_t usec = tv.tv_sec;
   usec *= 1000000;
   usec += tv.tv_usec;
APL_Integer z = 0;
   if      (unit == 1)         z = usec/1000000;
   else if (unit == 1000)      z = usec/1000;
   else if (unit == 1000000)   z = usec;
   else
      {
        MORE_ERROR() <<
  "Invalid time unit (use 1 for seconds, 1000 for ms, or 1000000 for μs)";
        DOMAIN_ERROR;
      }
   return Token(TOK_APL_VALUE1, IntScalar(z, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__51(Value_P B)
{
   if (B->element_count() < 6 || B->element_count() > 9)   LENGTH_ERROR;
tm t;
   t.tm_year = B->get_int_value(0) - 1900;
   t.tm_mon  = B->get_int_value(1) - 1;
   t.tm_mday = B->get_int_value(2);
   t.tm_hour = B->get_int_value(3);
   t.tm_min  = B->get_int_value(4);
   t.tm_sec  = B->get_int_value(5);
   if (B->element_count() > 6)   // dst provided
      t.tm_isdst = B->get_int_value(6);
   else
      t.tm_isdst = -1;
const time_t seconds = mktime(&t);
   if (seconds == time_t(-1))   DOMAIN_ERROR;
Value_P Z(4, LOC);
   Z->next_ravel_Int(seconds);
   Z->next_ravel_Int(t.tm_wday);
   Z->next_ravel_Int(t.tm_yday);
   Z->next_ravel_Int(t.tm_isdst);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__52(Value_P B, APL_Integer function_number)
{
   if (B->element_count() != 1)   LENGTH_ERROR;
const time_t t = B->get_int_value(0);
const tm * tmp = (function_number == 52) ? localtime(&t) : gmtime(&t);
   if (tmp == 0)   DOMAIN_ERROR;
Value_P Z(9, LOC);
   Z->next_ravel_Int(tmp->tm_year + 1900);
   Z->next_ravel_Int(tmp->tm_mon + 1);
   Z->next_ravel_Int(tmp->tm_mday);
   Z->next_ravel_Int(tmp->tm_hour);
   Z->next_ravel_Int(tmp->tm_min);
   Z->next_ravel_Int(tmp->tm_sec);
   Z->next_ravel_Int(tmp->tm_wday);
   Z->next_ravel_Int(tmp->tm_yday);
   Z->next_ravel_Int(tmp->tm_isdst);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__54(Value_P B)
{
const UCS_string path_ucs(*B.get());
const UTF8_string path(path_ucs);
   errno = chdir(path.c_str());
   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__57(Value_P B)
{
   CHECK_SECURITY(disable_Quad_FIO__exec);
   errno = 0;
const int fd = do_FIO_57(*B.get(), 0);
   if (fd == -1)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
   return Token(TOK_APL_VALUE1, IntScalar(fd, LOC));
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__6(Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
   clearerr(file);
char buffer[SMALL_BUF];
const size_t len = fread(buffer, 1, SMALL_BUF, file);
   if (len == 0)   return Token(TOK_APL_VALUE1, IntScalar(-errno, LOC));
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__60(Value_P B)
{
   if (!B->is_scalar())   RANK_ERROR;
const APL_Integer len = B->get_int_value(0);
   if (len < 1)   LENGTH_ERROR;
   if (len > 8)   LENGTH_ERROR;
Value_P Z = get_random(0, len);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Token
Quad_FIO::eval_XB__8(Value_P B)
{
   errno = 0;
FILE * file = get_FILE(*B);
   clearerr(file);
char buffer[SMALL_BUF];
const char * s = fgets(buffer, SMALL_BUF, file);
const int len = s ? strlen(s) : 0;
Value_P Z(len, LOC);
   loop(z, len)   Z->next_ravel_Int(buffer[z] & 0xFF);
   Z->check_value(LOC);
   return Token(TOK_APL_VALUE1, Z);
}
//────────────────────────────────────────────────────────────────────────────
Value_P
Quad_FIO::fds_to_val(fd_set * fds, int max_fd)
{
int fd_count = 0;
   if (fds)
      {
        for (int m = 0; m < max_fd; ++m)   if (FD_ISSET(m, fds))   ++fd_count;
      }

Value_P Z(ShapeItem(fd_count), LOC);
   if (fds)
      {
        for (int m = 0; m < max_fd; ++m)
            if (FD_ISSET(m, fds))   Z->next_ravel_Int(m);
      }

   return Z;
}
//────────────────────────────────────────────────────────────────────────────
FILE *
Quad_FIO::get_FILE(int handle)
{
file_entry & fe = get_file_entry(handle);
   if (fe.fe_FILE == 0)
      {
        if (fe.fe_may_read && fe.fe_may_write)
           fe.fe_FILE = fdopen(fe.fe_fd, "a+");
        else if (fe.fe_may_read)
           fe.fe_FILE = fdopen(fe.fe_fd, "r");
        else if (fe.fe_may_write)
           fe.fe_FILE = fdopen(fe.fe_fd, "a");
        else
           {
             MORE_ERROR() << "bad (closed ?) file handle " << handle;
             DOMAIN_ERROR;   // internal error
           }
      }

   return fe.fe_FILE;
}
//────────────────────────────────────────────────────────────────────────────
Quad_FIO::file_entry &
Quad_FIO::get_file_entry(int handle)
{
   loop(h, open_files.size())
      {
        if (open_files[h].fe_fd == handle)   return open_files[h];
      }

   MORE_ERROR() << handle
                << " is not an open file handle managed by ⎕FIO, see ⎕FIO 0.";
   DOMAIN_ERROR;
}
//────────────────────────────────────────────────────────────────────────────
Value_P
Quad_FIO::get_random(APL_Integer mode, APL_Integer len)
{
const int device = open("/dev/urandom", O_RDONLY);
   if (device == -1)
      {
        MORE_ERROR() << "⎕FIO[60] failed when trying to open /dev/urandom: "
                     << strerror(errno);
        DOMAIN_ERROR;
      }

unsigned char buffer[32];   // caller has checked that len <= 32
const ssize_t bytes = read(device, buffer, len);
   close(device);

   if (bytes == -1)
      {
        MORE_ERROR() << "⎕FIO[60] failed when trying to read /dev/urandom: "
                     << strerror(errno);
        DOMAIN_ERROR;
      }

   if (mode == 0)        // single integer result (len ≤ 8)
      {
         APL_Integer result = 0;
         loop(l, len)   result = result << 8 | (buffer[l] & 0xFF);
         return IntScalar(result, LOC);
      }
   else if (mode == 1)   // byte vector result
      {
        Value_P Z(len, LOC);
        loop(l, len)   Z->next_ravel_Int(buffer[l] & 0xFF);
         return Z;
      }

   MORE_ERROR() << "Invalid mode A in A ⎕FIO[60] B";
   DOMAIN_ERROR;
}
//────────────────────────────────────────────────────────────────────────────
void
Quad_FIO::group_thousands(UCS_string & dest, char * buffer, bool flt)
{
   // buffer is the 0-terminated and ASCII-only output of some snprintf("%..."),
   // and the user has requested thousands' separators in the integer part of
   // buffer.

   if (flt)   // buffer may or may not have a fractional part
      {
        if (char * dot = strchr(buffer, '.'))   // buffer has a  fractional part
           {
             *dot = 0;
             group_thousands(dest, buffer, false);
             dest << Workspace::get_FC(0) << (dot + 1);
             return;
           }
      }

   // at this point, buffer is integer only.
   //
int digit_count = 0;
   for (const char * b = buffer; *b; ++b)
       if (*b >= '0' && *b <= '9')   ++digit_count;

   for (const char * b = buffer; *b;)
       {
         const char cc = *b++;
         dest << Unicode(cc);
         if (cc >= '0' && cc <= '9')   // digit
            {
              if (--digit_count && !(digit_count % 3))
                 dest << Workspace::get_FC(1);
            }
         }
}
//────────────────────────────────────────────────────────────────────────────
APL_Integer
Quad_FIO::secs_epoch(const cValue & B)
{
   // B is a time/date like YYYY [MM [DD [HH [MM [SS]]]]]
   if (B.get_rank() > 1)   RANK_ERROR;
const int len_B = B.element_count();
   if (len_B < 1 || len_B > 6)   LENGTH_ERROR;

const struct {
               const char * name;
               int min_val;
               int max_val;
             } range[6] =
             {
               { "year",   0, 2037 },
               { "month",  1,   11 },
               { "day",    1,   31 },
               { "hour",   0,   23 },
               { "minute", 0,   59 },
               { "second", 0,   60 },
             };

int Bv[6];  // values as provided in B
   loop(b, 6)
       {
         if (len_B <= b)   Bv[b] = range[b].min_val;
         else              Bv[b] = B.get_int_value(b);
         if (Bv[b] < range[b].min_val)
            {
              MORE_ERROR() << "In ⎕FX.secs_epoch : B["
                           << (b + Workspace::get_IO())
                           <<  "] (aka. " << range[b].name
                           << ") is too small (the valid range is "
                           << range[b].min_val << "-"
                           << range[b].max_val << ")";
              DOMAIN_ERROR;
            }
         else if (Bv[b] > range[b].max_val)
            {
              MORE_ERROR() << "In ⎕FX.secs_epoch : B["
                           << (b + Workspace::get_IO())
                           <<  "] (aka. " << range[b].name
                           << ") is too large (the valid range is "
                           << range[b].min_val << "-"
                           << range[b].max_val << ")";
              DOMAIN_ERROR;
            }
       }

   if (Bv[0] < 100)   Bv[0] += 2000;   // interpret year xx as 20xx

tm tm;

                                  //                   APL B[]    mktime
   tm.tm_sec  = Bv[5];            // Seconds           0-60       (0-60)
   tm.tm_min  = Bv[4];            // Minutes           0-59       (0-59)
   tm.tm_hour = Bv[3];            // Hours             0-23       (0-23)
   tm.tm_mday = Bv[2];            // Day of the month  1-31       (1-31)
   tm.tm_mon  = Bv[1] - 1;        // Month             1-12       (0-11)
   tm.tm_year = Bv[0] - 1900;     // Year              2000...    1900...

const time_t z = mktime(&tm);
   if (z != time_t(-1))   return APL_Integer(z);

   MORE_ERROR() << "⎕FIO B: bad B";
   DOMAIN_ERROR;
}
//════════════════════════════════════════════════════════════════════════════

