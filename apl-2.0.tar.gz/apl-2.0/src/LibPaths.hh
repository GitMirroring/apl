/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2015-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#ifndef __LIBPATHS_HH_DEFINED__
#define __LIBPATHS_HH_DEFINED__

#include "UCS_string.hh"
#include "UTF8_string.hh"

class UCS_string_vector;

//────────────────────────────────────────────────────────────────────────────

/// a library reference number for commands )LOAD, )SAVE, and )COPY.
/// No library reference number is the same as LIB0.
enum LibRef
{
   LIB_NONE = -1,    ///< no library reference specified.
   LIB0 = 0,         ///< library 0
   LIB1 = 1,         ///< library 1
   LIB2 = 2,         ///< library 2
   LIB3 = 3,         ///< library 3
   LIB4 = 4,         ///< library 4
   LIB5 = 5,         ///< library 5
   LIB6 = 6,         ///< library 6
   LIB7 = 7,         ///< library 7
   LIB8 = 8,         ///< library 8
   LIB9 = 9,         ///< library 9
   LIB_MAX,          ///< valid library references are smaller than this
};
//════════════════════════════════════════════════════════════════════════════
/// a library reference number (0..9) and a workspace name
class LibRef_name
{
public:
  /// constructor (from WS name without libref)
  /// @param wsname workspace name without library reference
  /// @param allow_LIB_NONE if true, LIB_NONE is used when no libref is present
  LibRef_name(const UCS_string & wsname, bool allow_LIB_NONE)
  : lib(allow_LIB_NONE ? LIB_NONE : LIB0),
    name(wsname)
  {}

  /// constructor (from WS name with libref)
  /// @param wslib library reference number
  /// @param wsname workspace name
  LibRef_name(LibRef wslib, const UCS_string & wsname)
  : lib(wslib),

    name(wsname)
  {}

   /// constructor from an optional library reference number (0-9),
   /// followed by the mandatory WS name. Set name == "" on error.
   /// @param out output stream for error messages
   /// @param args command arguments (optional libref digit followed by name)
   /// @param allow_LIB_NONE if true, LIB_NONE is accepted as libref
   LibRef_name(ostream & out, const UCS_string_vector & args,
               bool allow_LIB_NONE);

   /// return the library reference
  LibRef get_libref() const
     { return lib; }

   /// return the workspace name
  const UCS_string & get_name() const
     { return name; }

   /// set the library reference
   /// @param new_lib new library reference to assign
   void set_libref(LibRef new_lib)
      { lib = new_lib; }

protected:
  LibRef lib;
  UCS_string name;
};
//════════════════════════════════════════════════════════════════════════════
/// a class mapping library reference numbers to directories
class LibPaths
{
public:
   /// one library directory
   struct LibDir
      {
        /// constructor: unspecified LibDir
        LibDir()
        : cfg_src(CSRC_NONE)
        {}

        /// how a dir_path was computed
        enum CfgSrc
           {
             CSRC_NONE      = 0,   ///< not at all
             CSRC_ENV       = 1,   ///< lib root from env. variable APL_LIB_ROOT
             CSRC_PWD       = 2,   ///< lib root from current directory
             CSRC_PREF_SYS  = 3,   ///< path from preferences file below /etc/
             CSRC_PREF_HOME = 4,   ///< path from preferences file below $HOME
             CSRC_CMD       = 5,   ///< lib root from )LIBS command
             CSRC_ARG       = 6,   ///< lib root from option --libroot
           };

        /// the path (name) of the lib directory
        UTF8_string dir_path;

        /// how this->dir_path was computed
        CfgSrc cfg_src;
      };

   /// return the path (directory) of the APL interpreter binary
   static const char * get_APL_bin_path()   { return APL_bin_path; }

   /// return the name (without directory) of the APL interpreter binary
   static const char * get_APL_bin_name()   { return APL_bin_name; }

   /// return directory containing (file or directory) workspaces and wslib1
   static const char * get_APL_lib_root()   { return APL_lib_root; }

   /// return source that configured \b this entry
   /// @param lib library reference to query
   static LibDir::CfgSrc get_cfg_src(LibRef lib)
      {
        // LIB_NONE (-1) means "no libref given", which is the same as
        // LIB0 (see LibRef_name's class comment); normalize it here
        // rather than indexing lib_dirs[-1] (Blake McBride, Bugs6 #3).
        if (lib == LIB_NONE)   lib = LIB0;
        Assert(lib >= LIB0 && lib < LIB_MAX);
        return lib_dirs[lib].cfg_src;
      }

   /// return the full path for lib/file \b lib_name, possibly adding
   /// the .ext1 or the .ext2 extension (if not provided)
   /// @param lib_name library reference and workspace name
   /// @param existing if true, look for an already-existing file
   /// @param ext1 preferred file extension to try first
   /// @param ext2 fallback file extension to try second
   static UTF8_string get_filename(const LibRef_name & lib_name, bool existing,
                                   const char * ext1, const char * ext2);

   /// return library path (from config file or from libroot)
   /// @param lib library reference whose directory is returned
   static UTF8_string get_lib_dir(LibRef lib);

   /// initialize library paths based on the location of the APL binary
   /// @param argv0 argv[0] of the interpreter process
   /// @param logit true to log path-search steps
   static void init(const char * argv0, bool logit);

   /// return 0 if directory \b lib) is present, otherwise the reason why not.
   /// @param lib library reference to check
   static const char * is_present(LibRef lib);

   /// remember the library root given with command line option --libroot
   /// (called before init(); it overrides $APL_LIB_ROOT and the LIBREF-N
   /// entries of the preferences files)
   /// @param dir the library root directory
   static void set_root_from_arg(const char * dir)   { root_arg = dir; }

   /// return true if the library root came from option --libroot
   static bool is_root_from_arg()   { return root_arg != 0; }

   /// set library root to \b new_root
   /// @param new_root new library root directory path
   static void set_APL_lib_root(const char * new_root);

   /// set library path (from config file)
   /// @param lib library reference number to configure
   /// @param path directory path for the library
   /// @param src source that provided this configuration
   static void set_lib_dir(LibRef lib, const UTF8_string & path,
                           LibDir::CfgSrc src);

   /// return true if directory \b dir contains two (files or sub-directories)
   /// workspaces and wslib1
   /// @param dir directory path to test
   static bool is_lib_root(const char * dir);

protected:
   /// maybe warn the user if two files that differ only by extension exist
   /// @param name_has_extension non-zero if the name already has an extension
   /// @param name base filename without extension
   /// @param ext1 first extension to check for ambiguity
   /// @param ext2 second extension to check for ambiguity
   static void maybe_warn_ambiguous(int name_has_extension,
                                    const UTF8_string name,
                                    const char * ext1, const char * ext2);

   /// compute the location of the apl binary
   /// @param argv0 argv[0] of the interpreter process
   /// @param logit true to log path-search steps
   static void compute_bin_path(const char * argv0, bool logit);

   /// set library root, searching from APL_bin_path
   static void search_APL_lib_root();

   /// the path (directory) of the APL interpreter binary
   static char APL_bin_path[];

   /// the name (without directory) of the APL interpreter binary
   static const char * APL_bin_name;

   /// a directory containing sub-directories workspaces and wslib1
   static char APL_lib_root[];

   /// directories for each library reference as specified in file preferences
   static LibDir lib_dirs[LIB_MAX];

   /// the library root from command line option --libroot (or 0)
   static const char * root_arg;

   /// true if APL_lib_root was computed from environment variable APL_LIB_ROOT
   static bool root_from_env;

   /// true if APL_lib_root was not found (thus "." taken as fallback)
   static bool root_from_pwd;
};
//════════════════════════════════════════════════════════════════════════════
#endif // __LIBPATHS_HH_DEFINED__
