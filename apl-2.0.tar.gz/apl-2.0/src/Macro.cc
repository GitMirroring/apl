/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#include <stdlib.h>

#include "Assert.hh"
#include "Macro.hh"
#include "UCS_string.hh"
#include "Workspace.hh"

Macro * Macro::all_macros[MAC_COUNT];
Symbol * Macro::mue_symbols[MARG_COUNT + 1];
bool Macro::mue_ready = false;

//════════════════════════════════════════════════════════════════════════════
void
Macro::init()
{
   // mue_symbols[0] (Macro_arg_num 0) is intentionally left at its
   // default-zero-initialised value (static storage duration, no
   // explicit initialiser) -- see its comment in Macro.hh.

   loop(n, MARG_COUNT)   // argument/local-var symbols μ1 .. μMARG_COUNT
      {
        UCS_string name;
        name << UNI_MUE << int(n + 1);
        mue_symbols[n + 1] = Workspace::lookup_symbol(name);
      }

   mue_ready = true;
}
//════════════════════════════════════════════════════════════════════════════
Macro::Macro(Macro_num num, const UTF8_string & text)
   : UserFunction(UCS_string(text), LOC, "Macro::Macro()",
                  true), macro_number(num)
{
// CERR << "MACRO: " << endl << text;

   all_macros[macro_number] = this;

   if (error_info || (error_line != -1))   // something went wrong
      {
        // this constructor runs for every global Macro::NAME object at
        // static-init time (see static_Objects.cc) -- CERR itself may not
        // yet be safe to use here (see FileBuffers.hh), so use get_CERR().
        get_CERR() << endl << "*** Fatal error in macro #" << macro_number << endl;
        if (error_info)         get_CERR() << "error_info: " << error_info << endl;
        if (error_line != -1)   get_CERR() << "error_line: " << error_line << endl;
        exit(1);
      }
}
//────────────────────────────────────────────────────────────────────────────
Macro *
Macro::get_macro(Macro_num num)
{
   Assert(num >= 0);
   Assert(num < MAC_COUNT);
   return all_macros[num];
}
//────────────────────────────────────────────────────────────────────────────
void
Macro::unmark_all_macros()
{
#define mac_def(name, _txt) get_macro(MAC_ ## name)->unmark_all_values();
#include "Macro.def"
}
//────────────────────────────────────────────────────────────────────────────
Macro::~Macro()
{
}
//════════════════════════════════════════════════════════════════════════════

