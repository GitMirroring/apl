/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#include "Avec.hh"
#include "Bif_F0_ZILDE.hh"
#include "Bif_F12_COMMA.hh"
#include "Bif_F12_DOMINO.hh"
#include "Bif_F12_ELEMENT.hh"
#include "Bif_F12_ENCODE_DECODE.hh"
#include "Bif_F12_EQUIV.hh"
#include "Bif_F12_FORMAT.hh"
#include "Bif_F12_INDEX_OF.hh"
#include "Bif_F12_INTERVAL_INDEX.hh"
#include "Bif_F12_PARTITION_PICK.hh"
#include "Bif_F12_RHO.hh"
#include "Bif_F12_ROTATE.hh"
#include "Bif_F12_SORT.hh"
#include "Bif_F12_TAKE_DROP.hh"
#include "Bif_F12_TRANSPOSE.hh"
#include "Bif_F12_UNION_INTER.hh"
#include "Bif_F1_EXECUTE.hh"
#include "Bif_F2_INDEX.hh"
#include "Bif_F2_LEFT_RIGHT.hh"
#include "Bif_OPER1_COMMUTE.hh"
#include "Bif_OPER1_EACH.hh"
#include "Bif_OPER1_REDUCE.hh"
#include "Bif_OPER1_SCAN.hh"
#include "Bif_OPER2_INNER.hh"
#include "Bif_OPER2_OUTER.hh"
#include "Bif_OPER2_POWER.hh"
#include "Bif_OPER2_RANK.hh"
#include "Common.hh"
#include "Id.hh"
#include "Output.hh"
#include "PrimitiveFunction.hh"
#include "PrintOperator.hh"
#include "QuadFunction.hh"
#include "Quad_CC.hh"
#include "Quad_DLX.hh"
#include "Quad_FFT.hh"
#include "Quad_FX.hh"
#include "Quad_GTK.hh"
#include "Quad_JSON.hh"
#include "Quad_MAP.hh"
#include "Quad_MX.hh"
#include "Quad_PLOT.hh"
#include "Quad_PNG.hh"
#include "Quad_RE.hh"
#include "Quad_RVAL.hh"
#include "Quad_SQL.hh"
#include "Quad_SVx.hh"
#include "Quad_TF.hh"
#include "Quad_XML.hh"
#include "ScalarFunction.hh"
#include "UCS_string.hh"
#include "Workspace.hh"

vector<ID> ID::all_IDs;

//════════════════════════════════════════════════════════════════════════════
const UTF8 *
ID::get_name(Id id)
{
   if (all_IDs.size() == 0)
      {
#define pp(i, _u, _v)  all_IDs.push_back(ID(ID_     ## i, #i));
#define qf(i,  u, _v) all_IDs.push_back(ID(ID_Quad_ ## i,  u));
#define qv(i,  u, _v) all_IDs.push_back(ID(ID_Quad_ ## i,  u));
#define sf(i,  u, _v) all_IDs.push_back(ID(ID_      ## i,  u));
#define st(i,  u, _v) all_IDs.push_back(ID(ID_      ## i,  u));
#include "Id.def"

        Heapsort<ID>::sort(all_IDs, ID::greater_id, 0);
      }

   if (const ID * found = Heapsort<ID>
                          ::search<Id>(id, all_IDs, ID::compare_id, 0))
      { return found->name_utf; }

   return reinterpret_cast<const UTF8 *>("unknown ID");
}
//────────────────────────────────────────────────────────────────────────────
ostream &
operator << (ostream & out, Id id)
{
   return out << ID::get_name(id);
}
//────────────────────────────────────────────────────────────────────────────
UCS_string
ID::get_name_UCS(Id id)
{
const UTF8 * name = get_name(id);
const UTF8_string utf(name);
   return UCS_string(utf);
}
//────────────────────────────────────────────────────────────────────────────
cFunction_P
ID::get_system_function(Id id)
{
   switch(id)
      {
#define pp(i, _u, _v)
#define qf(i, _u, _v) case ID_Quad_ ## i:   return &Quad_ ## i::fun;
#define qv(i, _u, _v)
#define sf(i, _u, _v) case ID_ ## i:        return &Bif_ ## i::fun;
#define st(i, _u, _v)

#include "Id.def"

        default: break;
      }

   return 0;
}
//────────────────────────────────────────────────────────────────────────────
Symbol *
ID::get_system_variable(Id id)
{
   switch(id)
      {
#define pp(_i, _u, _v)
#define qf(_i, _u, _v)
#define qv( i, _u, _v)   case ID_Quad_ ## i: \
                              return &Workspace::get_v_Quad_ ## i();
#define sf(_i, _u, _v) 
#define st(_i, _u, _v) 

#include "Id.def"

        default: break;
      }

   return 0;
}
//────────────────────────────────────────────────────────────────────────────
TokenTag
ID::get_token_tag(Id id)
{
   switch(id)
      {
#define pp(_i, _u, _v)
#define qf(_i, _u, _v)
#define qv( i, _u, _v)   case ID_Quad_ ## i: return TOK_Quad_## i;
#define sf(_i, _u, _v) 
#define st(_i, _u, _v) 

#include "Id.def"

        default: break;
      }

   return TOK_INVALID;
}
//════════════════════════════════════════════════════════════════════════════
