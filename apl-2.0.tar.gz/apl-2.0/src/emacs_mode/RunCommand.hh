/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright (C) 2014  Elias Mårtenson

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#ifndef RUN_COMMAND_HH
#define RUN_COMMAND_HH

#include "NetworkCommand.hh"

//════════════════════════════════════════════════════════════════════════════
/// the "run" network command: execute a block of APL statement lines sent
/// by the client and report the result
class RunCommand : public NetworkCommand {
public:
    /// constructor
    RunCommand( std::string name_in ) : NetworkCommand( name_in ) {};

    /// see NetworkCommand::run_command()
    virtual void run_command( NetworkConnection &conn, const std::vector<std::string> &args );
};
//════════════════════════════════════════════════════════════════════════════

#endif
