/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#ifndef __PARALLEL_HH_DEFINED__
#define __PARALLEL_HH_DEFINED__

#include <pthread.h>
#include "Common.hh"

// set PARALLEL_ENABLED if wanted and its prerequisites are satisfied
//
#if cfg_CORE_COUNT_WANTED == 0
   //
   // parallel not wanted
   //
#  undef PARALLEL_ENABLED

#elif HAVE_AFFINITY_NP
   //
   // parallel wanted and pthread_setaffinity_np() supported
   //
#  define PARALLEL_ENABLED 1

#else
   //
   // parallel wanted, but pthread_setaffinity_np() and friends are missing
   //
#  warning "CORE_COUNT_WANTED configured, but pthread_setaffinity_np() missing"
#  undef PARALLEL_ENABLED

#endif

#ifdef PARALLEL_ENABLED

#  define PRINT_LOCKED(x) \
   { sem_wait(Parallel::print_sema); x; sem_post(Parallel::print_sema); }

#else

#  define PRINT_LOCKED(x) x;

#endif // PARALLEL_ENABLED

#include <atomic>

#include <ostream>
#include <semaphore.h>

#include "Cell.hh"

using namespace std;

//════════════════════════════════════════════════════════════════════════════
/**
  Multi-core GNU APL uses a pool of threads numbered 0, 1, ... core_count()-1

  (master-) thread 0 is the interpreter (which also performs parallel work),
  while (worker-) threads 1 ... are only activated when some parallel work
  is available.

  The worker threads 1... are either working, or busy-waiting for work, or
  blocked on a semaphore:

         init
          ↓
       blocked ←→ busy-waiting ←→ working

  The transitions

      blocked ←→ busy-waiting

  occur before and after the master thread waits for terminal input or when
  the number of cores is being changed (with ⎕SYL[26;2]). The workers are
  blocked while the master thread waits for terminal input. The reason for this
  is that a busy-waiting worker is consuming power for no reason (to the extent
  that the CPU fan turns on even though there is no useful work in sight).

  The transitions

        busy-waiting ←→ working

  occurs when the execution of APL primitives, primarily scalar functions,
  suggests to execute in parallel (i.e. if the vectors involved are
  sufficiently long).

 **/
//════════════════════════════════════════════════════════════════════════════
/// The set of CPUs (= hyper-threads) over which the computational load is
/// being distrinuted.
class CPU_pool
{
public:
   /// constructor
   CPU_pool();

   /// add a CPU to the pool
   /// @param cpu CPU number to add
   static void add_CPU(CPU_Number cpu)
      { the_CPUs.push_back(cpu); }

   /// get the number of (active) CPUs
   static CoreCount get_count()
      { return CoreCount(the_CPUs.size()); }

   /// get the idx;th CPU
   /// @param idx zero-based index into the pool
   static CPU_Number get_CPU(size_t idx)
      { return the_CPUs[idx]; }

   /// resize the pool
   /// @param new_size new number of CPUs in the pool
   static void resize(CoreCount new_size)
      { the_CPUs.resize(new_size); }

   /// set new active core count, return true on error
   /// @param new_count desired number of active cores
   /// @param logit true to emit diagnostic messages
   static bool change_core_count(CoreCount new_count, bool logit);

   /// initialize the pool
   /// @param logit true to emit diagnostic messages during initialisation
   static void init(bool logit);

   /// make all pool members lock on their pool_sema
   /// @param logit true to emit diagnostic messages
   static void lock_pool(bool logit);

   /// unlock all pool members from their pool_sema
   /// @param logit true to emit diagnostic messages
   static void unlock_pool(bool logit);

protected:
   /// the CPU numbers that can be used
   static std::vector<CPU_Number> the_CPUs;
};
//════════════════════════════════════════════════════════════════════════════
/**
  A class coordinating the different cores working in parallel on the
  same ravel(s)
**/
/// Parallel APL execution
class Parallel
{
public:

   // we have two approaches to locking. One is based on std::atomic<int>,
   // the other is based on pthread_rwlock_wrlock().
   //
#if 1   /* use std::atomic<int> */

   /// a lock coordinating parallel access to shared objects
   typedef std::atomic<int> parallel_lock_t;
#  define LOCK_INITIALIZER { 0 }

   /// acquire \b lock
   /// @param lock lock variable to acquire
   static inline void acquire_lock(parallel_lock_t & lock)
      {
        for (;;)
            {
              if (lock.fetch_add(1) == 0)   return;   // got the lock
              lock.fetch_add(-1);   // undo the fetch_add()
            }
      }

   /// release \b lock
   /// @param lock lock variable to release
   static inline void release_lock(parallel_lock_t & lock)
      {
        lock.fetch_add(-1);
      }

#else   /* use pthread_rwlock_wrlock() */

   /// a lock coordinating parallel access to shared objects
   typedef pthread_rwlock_t parallel_lock_t;
#  define LOCK_INITIALIZER PTHREAD_RWLOCK_INITIALIZER

   static inline void acquire_lock(parallel_lock_t & lock)
     { pthread_rwlock_wrlock(&lock); }

   static inline void release_lock(parallel_lock_t & lock)
     { pthread_rwlock_unlock(&lock); }

#endif

   /// initialize
   /// @param logit true to emit diagnostic messages during initialisation
   static void init(bool logit);

   /// true if parallel execution is enabled
   static bool run_parallel;

   /// a semaphore to protect printing from different threads
   static sem_t * print_sema;

   /// a semaphore to tell when a thread has started
   static sem_t * pthread_create_sema;

   /// return the core number for \b idx
protected:
   /// initialize \b all_CPUs (which then determines the max. core count)
   static void init_all_CPUs(bool logit);

   /// the main() function of the worker threads
   static void * worker_main(void *);

   /// true after init() has been called
   static bool init_done;
};
//════════════════════════════════════════════════════════════════════════════

#endif // __PARALLEL_HH_DEFINED__
