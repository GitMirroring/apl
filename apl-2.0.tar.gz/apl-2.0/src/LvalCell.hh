/*
    This file is part of GNU APL, a free implementation of the
    ISO/IEC Standard 13751, "Programming Language APL, Extended"

    Copyright © 2008-2026  Dr. Jürgen Sauermann

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/** @file
*/

#ifndef __LVALCELL_HH_DEFINED__
#define __LVALCELL_HH_DEFINED__

#include "Cell.hh"

//════════════════════════════════════════════════════════════════════════════
/**
    A cell pointing to another cell.
    This is used for selective assignments.
 **/
/// A cell pointing to another cell (which shall be updated)
class LvalCell : public Cell
{
public:
   /// Constructor: a cell pointing to another cell
   /// @param cell        target cell that this lval points to
   /// @param cell_owner  value that owns the target cell
   LvalCell(Cell * cell, Value * cell_owner);

   /// Constructor: copy from other LvalCell
   /// @param other  source LvalCell to copy from
   LvalCell(const LvalCell & other);

   /// Overloaded Cell::is_lval_cell()
   virtual bool is_lval_cell()  const   { return true; }

   /// Overloaded Cell::get_cell_owner(): the owner of the cell pointed to
   virtual Value * get_cell_owner() const
      { return value.pval.owner; }

   /// Overloaded Cell::character_representation()
   /// @param pctx  print context controlling format
   virtual PrintBuffer character_representation(const PrintContext &pctx) const;

   /// Overloaded Cell::get_lval_value()
   virtual Cell * get_lval_value() const;

   /// Overloaded Cell::check_consistency(): make sure that owner (if any)
   /// owns this Cell
   virtual void check_consistency() const;

   /// overloaded Cell::init_other
   /// @param other       raw memory for the new cell to initialise
   /// @param cell_owner  value that will own the new cell
   /// @param loc         caller location for diagnostics
   virtual void init_other(void * other, Value & cell_owner,
                           const char * loc) const;

protected:
   /// Overloaded Cell::get_classname().
   virtual const char * get_classname() const   { return "LvalCell"; }

  /// Overloaded Cell::CDR_size() should not be called for lval cells
   virtual int CDR_size() const
      { NeverReach("CDR_size called on LvalCell base class"); return 0; }

   ///  Overloaded Cell::get_cell_type()
   virtual CellType get_cell_type() const
      { return CT_CELLREF; }

   /// Overloaded Cell::greater().
   virtual bool greater(const Cell & other) const
      { DOMAIN_ERROR; }
};
//════════════════════════════════════════════════════════════════════════════

#endif // __LVALCELL_HH_DEFINED__
